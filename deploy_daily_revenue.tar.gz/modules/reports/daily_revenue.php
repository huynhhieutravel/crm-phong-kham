<?php
// modules/reports/daily_revenue.php
require_once '../../includes/db.php';
require_once '../../includes/functions.php';
require_once '../../includes/auth_middleware.php';
require_permission('view_reports');

$page_title = 'Báo Cáo Thực Thu';
$current_page = 'reports';
require_once '../../templates/header.php';

$db = getDB();

// Date filter
$report_date = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');
$period = isset($_GET['period']) ? $_GET['period'] : 'today';

if ($period === 'today') {
    $start = date('Y-m-d') . ' 00:00:00';
    $end = date('Y-m-d') . ' 23:59:59';
    $label = 'Hôm nay (' . date('d/m/Y') . ')';
} elseif ($period === 'custom' && $report_date) {
    $start = $report_date . ' 00:00:00';
    $end = $report_date . ' 23:59:59';
    $label = 'Ngày ' . date('d/m/Y', strtotime($report_date));
} elseif ($period === 'week') {
    $start = date('Y-m-d', strtotime('monday this week')) . ' 00:00:00';
    $end = date('Y-m-d', strtotime('sunday this week')) . ' 23:59:59';
    $label = 'Tuần này';
} elseif ($period === 'month') {
    $start = date('Y-m-01') . ' 00:00:00';
    $end = date('Y-m-t') . ' 23:59:59';
    $label = 'Tháng ' . date('m/Y');
} else {
    $start = date('Y-m-d') . ' 00:00:00';
    $end = date('Y-m-d') . ' 23:59:59';
    $label = 'Hôm nay';
}

$params = [$start, $end];

// 1. KPIs Tổng quan từ Invoices
$stmt = $db->prepare("
    SELECT 
        SUM(cash_amount) as total_cash,
        SUM(transfer_amount) as total_transfer,
        SUM(package_deduct) as total_package,
        SUM(debt_amount) as total_debt
    FROM invoices
    WHERE created_at BETWEEN ? AND ?
");
$stmt->execute($params);
$inv_totals = $stmt->fetch();

// 2. Thu Nợ (Từ package_payments)
$stmt = $db->prepare("
    SELECT payment_method, SUM(amount) as total
    FROM package_payments
    WHERE paid_at BETWEEN ? AND ?
    GROUP BY payment_method
");
$stmt->execute($params);
$pkg_pays = $stmt->fetchAll();

$total_cash = (float)$inv_totals['total_cash'];
$total_transfer = (float)$inv_totals['total_transfer'];
$total_package = (float)$inv_totals['total_package'];
$total_debt = (float)$inv_totals['total_debt'];

foreach ($pkg_pays as $pp) {
    if ($pp['payment_method'] === 'cash') {
        $total_cash += (float)$pp['total'];
    } elseif (in_array($pp['payment_method'], ['transfer', 'transfer_personal', 'transfer_company', 'card'])) {
        // Cộng gộp tất cả các loại chuyển khoản (và quẹt thẻ nếu có) vào mục Chuyển khoản chung
        $total_transfer += (float)$pp['total'];
    }
}

// Thực thu CHỈ tính Tiền mặt + Chuyển khoản thực tế
$total_revenue = $total_cash + $total_transfer; 

// 3. Chi Tiết Nợ Phát Sinh (Invoices có debt_amount > 0)
$stmt = $db->prepare("
    SELECT i.*, p.full_name as patient_name, u.full_name as created_by_name
    FROM invoices i
    JOIN patients p ON i.patient_id = p.id
    LEFT JOIN users u ON i.created_by = u.id
    WHERE i.debt_amount > 0 AND i.created_at BETWEEN ? AND ?
    ORDER BY i.created_at DESC
");
$stmt->execute($params);
$debt_invoices = $stmt->fetchAll();

// 4. Chi Tiết Thu Nợ Cũ (package_payments)
$stmt = $db->prepare("
    SELECT ppay.*, p.full_name as patient_name, pkg.name as package_name, u.full_name as created_by_name
    FROM package_payments ppay
    JOIN patient_packages pp ON ppay.patient_package_id = pp.id
    JOIN patients p ON pp.patient_id = p.id
    JOIN packages pkg ON pp.package_id = pkg.id
    LEFT JOIN users u ON ppay.created_by = u.id
    WHERE ppay.paid_at BETWEEN ? AND ?
    ORDER BY ppay.paid_at DESC
");
$stmt->execute($params);
$debt_payments = $stmt->fetchAll();

// 5. Năng suất Nhân viên (Nối qua treatment_id)
$stmt = $db->prepare("
    SELECT u.full_name, u.id as user_id,
           COUNT(DISTINCT t.id) as total_cases,
           SUM(COALESCE(i.cash_amount, 0) + COALESCE(i.transfer_amount, 0)) as cash_revenue,
           SUM(COALESCE(i.package_deduct, 0)) as package_value,
           SUM(COALESCE(i.debt_amount, 0)) as debt_amount
    FROM treatments t
    JOIN users u ON t.technician_id = u.id
    LEFT JOIN invoices i ON t.id = i.treatment_id
    WHERE t.treatment_date BETWEEN ? AND ?
    GROUP BY u.id
    ORDER BY total_cases DESC
");
$stmt->execute($params);
$staff_data = $stmt->fetchAll();

// 6. Tất cả Giao Dịch Phiếu Tính Tiền (Invoices)
$stmt = $db->prepare("
    SELECT i.*, p.full_name as patient_name, u.full_name as created_by_name
    FROM invoices i
    JOIN patients p ON i.patient_id = p.id
    LEFT JOIN users u ON i.created_by = u.id
    WHERE i.created_at BETWEEN ? AND ?
    ORDER BY i.created_at DESC
");
$stmt->execute($params);
$all_invoices = $stmt->fetchAll();
?>

<style>
.rev-outer { max-width: 1400px; width: 100%; }
.rev-filter {
    display: flex; align-items: center; gap: 1rem; flex-wrap: wrap;
    margin-bottom: 2rem; padding: 1.5rem; background: white; border-radius: 18px; box-shadow: 0 4px 20px rgba(0,0,0,0.03);
}
.rev-toggle { display: flex; background: #f1f5f9; padding: 5px; border-radius: 14px; gap: 4px; }
.rev-toggle a {
    padding: 0.6rem 1.2rem; border-radius: 10px; font-size: 0.85rem; font-weight: 600; color: #64748b;
    text-decoration: none; transition: all 0.2s; border: none; background: transparent;
}
.rev-toggle a:hover:not(.active) { background: rgba(255,255,255,0.6); color: var(--primary); }
.rev-toggle a.active { background: white; color: var(--primary); box-shadow: 0 4px 12px rgba(0,0,0,0.08); }

.rev-stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 1.5rem; margin-bottom: 2rem; }
@media (max-width: 1024px) { .rev-stats { grid-template-columns: repeat(2, 1fr); } }
@media (max-width: 600px) { .rev-stats { grid-template-columns: 1fr; } }

.rev-card {
    padding: 2rem; border-radius: 20px; color: white; position: relative; overflow: hidden;
    box-shadow: 0 10px 25px -5px rgba(0,0,0,0.1); transition: all 0.3s;
}
.rev-card:hover { transform: translateY(-4px); }
.rev-card .rev-icon { position: absolute; right: -5px; bottom: -5px; font-size: 4rem; opacity: 0.15; }
.rev-card .rev-label { font-size: 0.8rem; font-weight: 700; text-transform: uppercase; opacity: 0.85; letter-spacing: 0.5px; }
.rev-card .rev-val { font-size: 2rem; font-weight: 800; margin-top: 0.5rem; }
.rev-card .rev-sub { font-size: 0.85rem; opacity: 0.8; margin-top: 0.3rem; }

.section-card { background: white; border-radius: 20px; padding: 2rem; margin-bottom: 1.5rem; box-shadow: 0 4px 20px rgba(0,0,0,0.03); }
.section-title { font-size: 1.15rem; font-weight: 800; color: #1e293b; margin-bottom: 1.5rem; display: flex; align-items: center; justify-content: space-between; gap: 0.6rem; }
.section-title i { color: var(--primary); }
</style>

<div class="content-body">
    <div class="rev-outer">
        <div class="breadcrumb mb-2" style="font-size: 0.75rem; font-weight: 700; letter-spacing: 1px; color: #94a3b8;">
            CRM / BÁO CÁO / THỰC THU
        </div>
        <h1 style="font-size: 2rem; font-weight: 800; color: #0f172a; margin-bottom: 1.5rem;">
            💰 Báo Cáo Thực Thu — <?php echo $label; ?>
        </h1>

        <!-- Filter -->
        <div class="rev-filter">
            <div class="rev-toggle">
                <a href="?period=today" class="<?php echo $period === 'today' ? 'active' : ''; ?>">Hôm nay</a>
                <a href="?period=week" class="<?php echo $period === 'week' ? 'active' : ''; ?>">Tuần này</a>
                <a href="?period=month" class="<?php echo $period === 'month' ? 'active' : ''; ?>">Tháng này</a>
            </div>
            <form method="GET" style="display: flex; align-items: center; gap: 0.5rem;">
                <input type="hidden" name="period" value="custom">
                <input type="date" name="date" value="<?php echo $report_date; ?>" class="form-input" style="border-radius: 10px; padding: 0.5rem 0.8rem; font-weight: 600;">
                <button type="submit" class="btn btn-primary" style="border-radius: 10px; padding: 0.5rem 1rem;">Xem</button>
            </form>
        </div>

        <!-- Revenue KPIs -->
        <div class="rev-stats">
            <div class="rev-card" style="background: linear-gradient(135deg, #10b981, #34d399);">
                <div class="rev-icon">💵</div>
                <div class="rev-label">Tiền Mặt</div>
                <div class="rev-val"><?php echo format_money($total_cash); ?></div>
            </div>
            <div class="rev-card" style="background: linear-gradient(135deg, #3b82f6, #60a5fa);">
                <div class="rev-icon">🏦</div>
                <div class="rev-label">Chuyển Khoản</div>
                <div class="rev-val"><?php echo format_money($total_transfer); ?></div>
            </div>
            <div class="rev-card" style="background: linear-gradient(135deg, #8b5cf6, #a78bfa);">
                <div class="rev-icon">📦</div>
                <div class="rev-label">Gói Cấn Trừ (Chỉ số)</div>
                <div class="rev-val"><?php echo format_money($total_package); ?></div>
                <div class="rev-sub">Không tính vào Thực Thu</div>
            </div>
            <div class="rev-card" style="background: linear-gradient(135deg, #ef4444, #f87171);">
                <div class="rev-icon">📝</div>
                <div class="rev-label">Nợ Phát Sinh Mới</div>
                <div class="rev-val"><?php echo format_money($total_debt); ?></div>
            </div>
        </div>

        <!-- Total Summary -->
        <div class="section-card" style="background: linear-gradient(135deg, #0f172a, #1e293b); color: white; text-align: center; padding: 2.5rem;">
            <div style="font-size: 0.9rem; font-weight: 700; text-transform: uppercase; opacity: 0.7; letter-spacing: 1px; color: #38bdf8;">TỔNG THỰC THU (Mặt + CK)</div>
            <div style="font-size: 3.5rem; font-weight: 800; margin-top: 0.5rem; color: #38bdf8; text-shadow: 0 4px 15px rgba(56, 189, 248, 0.4);"><?php echo format_money($total_revenue); ?></div>
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem;">
            <!-- Debt Created (Nợ Phát Sinh) -->
            <div class="section-card">
                <div class="section-title">
                    <span><i class="fas fa-hand-holding-usd" style="color: #ef4444;"></i> Nợ Phát Sinh Hôm Nay</span>
                    <span style="font-size: 0.8rem; background: #fef2f2; color: #ef4444; padding: 0.2rem 0.6rem; border-radius: 50px;"><?php echo count($debt_invoices); ?> khoản</span>
                </div>
                <?php if (empty($debt_invoices)): ?>
                    <div style="text-align: center; padding: 2rem; color: #94a3b8;">Không có nợ phát sinh trong kỳ.</div>
                <?php else: ?>
                    <div style="max-height: 350px; overflow-y: auto;">
                        <table class="table" style="width: 100%;">
                            <thead>
                                <tr style="border-bottom: 2px solid #e2e8f0; text-align: left; position: sticky; top: 0; background: white;">
                                    <th style="padding: 0.6rem;">Bệnh nhân</th>
                                    <th style="padding: 0.6rem;">Mã HĐ</th>
                                    <th style="padding: 0.6rem; text-align: right;">Ghi Nợ</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($debt_invoices as $di): ?>
                                    <tr style="border-bottom: 1px solid #f1f5f9;">
                                        <td style="padding: 0.6rem;">
                                            <a href="../patients/view.php?id=<?php echo $di['patient_id']; ?>" style="font-weight: 700; color: var(--primary); text-decoration: none;">
                                                <?php echo e($di['patient_name']); ?>
                                            </a>
                                        </td>
                                        <td style="padding: 0.6rem; font-size: 0.85rem; color: #64748b;"><?php echo e($di['invoice_no']); ?></td>
                                        <td style="padding: 0.6rem; text-align: right; font-weight: 800; color: #ef4444;"><?php echo format_money($di['debt_amount']); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Debt Payments Collected (Thu Nợ Cũ) -->
            <div class="section-card">
                <div class="section-title">
                    <span><i class="fas fa-piggy-bank" style="color: #10b981;"></i> Thu Nợ Cũ Hôm Nay</span>
                    <span style="font-size: 0.8rem; background: #ecfdf5; color: #10b981; padding: 0.2rem 0.6rem; border-radius: 50px;"><?php echo count($debt_payments); ?> khoản</span>
                </div>
                <?php if (empty($debt_payments)): ?>
                    <div style="text-align: center; padding: 2rem; color: #94a3b8;">Không có khoản thu nợ nào trong kỳ.</div>
                <?php else: ?>
                    <div style="max-height: 350px; overflow-y: auto;">
                        <table class="table" style="width: 100%;">
                            <thead>
                                <tr style="border-bottom: 2px solid #e2e8f0; text-align: left; position: sticky; top: 0; background: white;">
                                    <th style="padding: 0.6rem;">Bệnh nhân</th>
                                    <th style="padding: 0.6rem;">Hình thức</th>
                                    <th style="padding: 0.6rem; text-align: right;">Đã thu</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($debt_payments as $dp): ?>
                                    <tr style="border-bottom: 1px solid #f1f5f9;">
                                        <td style="padding: 0.6rem;">
                                            <div style="font-weight: 700; color: #1e293b;"><?php echo e($dp['patient_name']); ?></div>
                                            <div style="font-size: 0.75rem; color: #64748b;"><?php echo e($dp['package_name']); ?></div>
                                        </td>
                                        <td style="padding: 0.6rem;">
                                            <?php if ($dp['payment_method'] === 'cash'): ?>
                                                <span style="font-size: 0.75rem; background: #d1fae5; color: #059669; padding: 0.2rem 0.5rem; border-radius: 6px; font-weight: 700;"><i class="fas fa-money-bill"></i> Tiền mặt</span>
                                            <?php else: ?>
                                                <span style="font-size: 0.75rem; background: #dbeafe; color: #2563eb; padding: 0.2rem 0.5rem; border-radius: 6px; font-weight: 700;"><i class="fas fa-university"></i> Chuyển khoản</span>
                                            <?php endif; ?>
                                        </td>
                                        <td style="padding: 0.6rem; text-align: right; font-weight: 800; color: #10b981;">
                                            +<?php echo format_money($dp['amount']); ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem;">
            <!-- Staff Productivity -->
            <div class="section-card">
                <div class="section-title"><span><i class="fas fa-user-tie" style="color: #6366f1;"></i> Năng Suất Nhân Viên</span></div>
                <?php if (empty($staff_data)): ?>
                    <div style="text-align: center; padding: 2rem; color: #94a3b8;">Không có dữ liệu trong kỳ.</div>
                <?php else: ?>
                    <table class="table" style="width: 100%;">
                        <thead>
                            <tr style="border-bottom: 2px solid #e2e8f0; text-align: left;">
                                <th style="padding: 0.6rem;">KTV / Bác sĩ</th>
                                <th style="padding: 0.6rem; text-align: center;">Số ca</th>
                                <th style="padding: 0.6rem; text-align: right;">Tiền thu</th>
                                <th style="padding: 0.6rem; text-align: right;">Gói (quy đổi)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($staff_data as $s): ?>
                                <tr style="border-bottom: 1px solid #f1f5f9;">
                                    <td style="padding: 0.6rem; font-weight: 700;"><?php echo e($s['full_name']); ?></td>
                                    <td style="padding: 0.6rem; text-align: center;">
                                        <span style="font-size: 1.1rem; font-weight: 800; color: #1e293b;"><?php echo $s['total_cases']; ?></span>
                                        <span style="font-size: 0.8rem; color: #64748b;"> ca</span>
                                    </td>
                                    <td style="padding: 0.6rem; text-align: right; font-weight: 700; color: #10b981;">
                                        <?php echo format_money($s['cash_revenue']); ?>
                                    </td>
                                    <td style="padding: 0.6rem; text-align: right; font-weight: 700; color: #8b5cf6;">
                                        <?php echo format_money($s['package_value']); ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
            
            <div class="section-card">
                <div style="text-align: center; padding: 4rem 2rem; border: 2px dashed #e2e8f0; border-radius: 16px; background: #f8fafc; height: 100%; display: flex; flex-direction: column; justify-content: center; align-items: center;">
                    <i class="fas fa-chart-line" style="font-size: 4rem; color: #cbd5e1; margin-bottom: 1rem;"></i>
                    <h4 style="margin: 0; color: #64748b; font-weight: 800;">Phân Tích Sắp Tới</h4>
                    <p style="font-size: 0.85rem; color: #94a3b8; margin-top: 0.5rem; max-width: 250px;">Biểu đồ xu hướng và phân tích tỷ trọng dịch vụ sẽ sớm ra mắt.</p>
                </div>
            </div>
        </div>

        <!-- All Transactions -->
        <div class="section-card">
            <div class="section-title"><span><i class="fas fa-receipt" style="color: #64748b;"></i> Tất Cả Phiếu Tính Tiền Mới Phát Sinh (<?php echo count($all_invoices); ?>)</span></div>
            <?php if (empty($all_invoices)): ?>
                <div style="text-align: center; padding: 2rem; color: #94a3b8;">Chưa có phiếu tính tiền nào trong kỳ.</div>
            <?php else: ?>
                <div style="max-height: 500px; overflow-y: auto;">
                    <table class="table" style="width: 100%;">
                        <thead>
                            <tr style="border-bottom: 2px solid #e2e8f0; text-align: left; position: sticky; top: 0; background: white; z-index: 10;">
                                <th style="padding: 0.6rem;">Thời gian</th>
                                <th style="padding: 0.6rem;">Khách hàng</th>
                                <th style="padding: 0.6rem;">Mã Phiếu</th>
                                <th style="padding: 0.6rem;">Hình thức</th>
                                <th style="padding: 0.6rem; text-align: right;">Tổng Hoá Đơn</th>
                                <th style="padding: 0.6rem;">Người tạo</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($all_invoices as $inv): ?>
                                <tr style="border-bottom: 1px solid #f1f5f9;">
                                    <td style="padding: 0.6rem;">
                                        <div style="font-weight: 700; font-size: 0.9rem; color: #1e293b;"><?php echo date('H:i', strtotime($inv['created_at'])); ?></div>
                                        <div style="font-size: 0.75rem; color: #64748b;"><?php echo date('d/m/Y', strtotime($inv['created_at'])); ?></div>
                                    </td>
                                    <td style="padding: 0.6rem; font-weight: 700; color: var(--primary);">
                                        <a href="../patients/view.php?id=<?php echo $inv['patient_id']; ?>" style="text-decoration: none; color: inherit;">
                                            <?php echo e($inv['patient_name']); ?>
                                        </a>
                                    </td>
                                    <td style="padding: 0.6rem;">
                                        <a href="#" onclick="openInvoicePreview(<?php echo $inv['id']; ?>); return false;" style="font-size: 0.85rem; font-weight: 700; color: #64748b; text-decoration: underline;">
                                            <?php echo e($inv['invoice_no']); ?>
                                        </a>
                                    </td>
                                    <td style="padding: 0.6rem;">
                                        <div style="display: flex; gap: 4px; flex-wrap: wrap;">
                                            <?php if ($inv['cash_amount'] > 0): ?>
                                                <span style="font-size: 0.7rem; background: #d1fae5; color: #059669; padding: 0.1rem 0.4rem; border-radius: 4px; font-weight: 700;">Tiền mặt</span>
                                            <?php endif; ?>
                                            <?php if ($inv['transfer_amount'] > 0): ?>
                                                <span style="font-size: 0.7rem; background: #dbeafe; color: #2563eb; padding: 0.1rem 0.4rem; border-radius: 4px; font-weight: 700;">CK</span>
                                            <?php endif; ?>
                                            <?php if ($inv['package_deduct'] > 0): ?>
                                                <span style="font-size: 0.7rem; background: #f3e8ff; color: #7e22ce; padding: 0.1rem 0.4rem; border-radius: 4px; font-weight: 700;">Trừ Gói</span>
                                            <?php endif; ?>
                                            <?php if ($inv['debt_amount'] > 0): ?>
                                                <span style="font-size: 0.7rem; background: #fee2e2; color: #dc2626; padding: 0.1rem 0.4rem; border-radius: 4px; font-weight: 700;">Ghi Nợ</span>
                                            <?php endif; ?>
                                            <?php if ($inv['total_amount'] == 0 && $inv['package_deduct'] == 0 && $inv['debt_amount'] == 0): ?>
                                                <span style="font-size: 0.7rem; background: #f1f5f9; color: #475569; padding: 0.1rem 0.4rem; border-radius: 4px; font-weight: 700;">0đ</span>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                    <td style="padding: 0.6rem; text-align: right; font-weight: 800; color: #1e293b; font-size: 1.05rem;">
                                        <?php echo format_money($inv['total_amount']); ?>
                                    </td>
                                    <td style="padding: 0.6rem; font-size: 0.8rem; color: #64748b;"><?php echo e($inv['created_by_name']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include_once '../../includes/invoice_popup.php'; ?>

<?php require_once '../../templates/footer.php'; ?>
