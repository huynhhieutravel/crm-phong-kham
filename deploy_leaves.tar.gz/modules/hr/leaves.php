<?php
// modules/hr/leaves.php
require_once '../../includes/db.php';
require_once '../../includes/functions.php';
require_once '../../includes/auth_middleware.php';

$page_title = 'Quản lý Đơn Nghỉ Phép';
$current_page = 'leaves';
require_once '../../templates/header.php';

$db = getDB();
$uid = (int)$_SESSION['user_id'];
$role = strtolower($_SESSION['role'] ?? '');
$is_admin = in_array($role, ['admin', 'doctor']) || can('view_hr');

$filter_status = $_GET['status'] ?? '';
$filter_month = $_GET['month'] ?? date('Y-m');

// Build query
$where = [];
$params = [];

if (!$is_admin) {
    // Normal users only see their own requests
    $where[] = "lr.user_id = ?";
    $params[] = $uid;
}
if ($filter_status !== '') {
    $where[] = "lr.status = ?";
    $params[] = $filter_status;
}
if ($filter_month !== '') {
    $where[] = "DATE_FORMAT(lr.start_date, '%Y-%m') = ?";
    $params[] = $filter_month;
}

$where_sql = count($where) > 0 ? 'WHERE ' . implode(' AND ', $where) : '';

$stmt = $db->prepare("
    SELECT lr.*, u.full_name as user_name, r.display_name as role_name
    FROM leave_requests lr
    JOIN users u ON lr.user_id = u.id
    JOIN roles r ON u.role_id = r.id
    $where_sql
    ORDER BY lr.created_at DESC
");
$stmt->execute($params);
$leaves = $stmt->fetchAll();
?>

<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
    <h2 style="margin: 0; font-weight: 800; color: var(--text-main);">ĐƠN NGHỈ PHÉP CỦA TÔI</h2>
    <div style="display: flex; gap: 1rem;">
        <button onclick="document.getElementById('leaveModal').style.display='flex'" class="btn btn-primary shadow-sm" style="background: var(--primary); color: white; border-radius: 12px; padding: 0.75rem 1.5rem; font-weight: 700; display: flex; align-items: center; gap: 0.5rem; border: none; cursor: pointer;">
            <i class="fas fa-plus"></i> Tạo Đơn Nghỉ Phép
        </button>
    </div>
</div>

<div class="card" style="margin-bottom: 1.5rem;">
    <form method="GET" style="display: flex; gap: 1rem; flex-wrap: wrap; align-items: flex-end;">
        <div class="form-group" style="margin: 0; min-width: 200px;">
            <label class="form-label" style="font-size: 0.8rem; text-transform: uppercase;">Trạng thái</label>
            <select name="status" class="form-input" style="padding: 0.6rem 1rem;">
                <option value="">Tất cả trạng thái</option>
                <option value="pending" <?php echo $filter_status === 'pending' ? 'selected' : ''; ?>>Chờ duyệt</option>
                <option value="approved" <?php echo $filter_status === 'approved' ? 'selected' : ''; ?>>Đã duyệt</option>
                <option value="rejected" <?php echo $filter_status === 'rejected' ? 'selected' : ''; ?>>Từ chối</option>
            </select>
        </div>
        <div class="form-group" style="margin: 0; min-width: 200px;">
            <label class="form-label" style="font-size: 0.8rem; text-transform: uppercase;">Tháng</label>
            <input type="month" name="month" class="form-input" style="padding: 0.6rem 1rem;" value="<?php echo htmlspecialchars($filter_month); ?>">
        </div>
        <button type="submit" class="btn" style="background: #f1f5f9; color: #475569; padding: 0.6rem 1.5rem;"><i class="fas fa-filter"></i> Lọc</button>
        <?php if ($filter_status !== '' || $filter_month !== date('Y-m')): ?>
            <a href="leaves.php" class="btn" style="background: none; color: #94a3b8; text-decoration: underline; padding: 0.6rem 1rem;">Xóa lọc</a>
        <?php endif; ?>
    </form>
</div>

<div class="card">
    <table class="table" style="width: 100%;">
        <thead>
            <tr style="text-align: left; border-bottom: 2px solid #f1f5f9; color: #64748b; font-size: 0.8rem; text-transform: uppercase;">
                <th style="padding: 1rem;">Nhân sự</th>
                <th style="padding: 1rem;">Từ ngày</th>
                <th style="padding: 1rem;">Đến ngày</th>
                <th style="padding: 1rem;">Lý do</th>
                <th style="padding: 1rem;">Ngày nộp</th>
                <th style="padding: 1rem; width: 150px;">Trạng thái</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($leaves as $l): ?>
                <tr style="border-bottom: 1px solid #f1f5f9; transition: background 0.2s;" onmouseover="this.style.background='#f8fafc'" onmouseout="this.style.background='transparent'">
                    <td style="padding: 1rem;">
                        <div style="font-weight: 700; color: #1e293b;"><?php echo e($l['user_name']); ?></div>
                        <div style="font-size: 0.75rem; color: #94a3b8; margin-top: 0.2rem;"><?php echo e($l['role_name']); ?></div>
                    </td>
                    <td style="padding: 1rem; font-weight: 500;"><?php echo date('d/m/Y', strtotime($l['start_date'])); ?></td>
                    <td style="padding: 1rem; font-weight: 500;"><?php echo date('d/m/Y', strtotime($l['end_date'])); ?></td>
                    <td style="padding: 1rem; color: #64748b; font-size: 0.85rem; max-width: 200px;"><?php echo e($l['reason'] ?: '—'); ?></td>
                    <td style="padding: 1rem; color: #94a3b8; font-size: 0.85rem;"><?php echo date('d/m/Y H:i', strtotime($l['created_at'])); ?></td>
                    <td style="padding: 1rem; width: 1%; white-space: nowrap;">
                        <?php if ($l['status'] === 'pending'): ?>
                            <div style="display: flex; gap: 0.5rem; align-items: center;">
                                <span style="background: #fdfce7; color: #ca8a04; padding: 0.35rem 0.75rem; border-radius: 6px; font-size: 0.75rem; font-weight: 700; border: 1px solid #fef08a; white-space: nowrap;">Chờ duyệt</span>
                                <?php if ($is_admin): ?>
                                    <button onclick="handleLeaveAction(<?php echo $l['id']; ?>, 'approve')" class="btn" style="background: #10b981; color: white; padding: 0.35rem 0.6rem; font-size: 0.75rem; border-radius: 6px; border: none; cursor: pointer; font-weight: 600;" title="Duyệt"><i class="fas fa-check"></i></button>
                                    <button onclick="handleLeaveAction(<?php echo $l['id']; ?>, 'reject')" class="btn" style="background: #ef4444; color: white; padding: 0.35rem 0.6rem; font-size: 0.75rem; border-radius: 6px; border: none; cursor: pointer; font-weight: 600;" title="Từ chối"><i class="fas fa-times"></i></button>
                                <?php endif; ?>
                            </div>
                        <?php elseif ($l['status'] === 'approved'): ?>
                            <span style="background: #dcfce7; color: #16a34a; padding: 0.35rem 0.75rem; border-radius: 20px; font-size: 0.75rem; font-weight: 700; border: 1px solid #bbf7d0; white-space: nowrap;">Đã duyệt</span>
                        <?php else: ?>
                            <span style="background: #fee2e2; color: #ef4444; padding: 0.35rem 0.75rem; border-radius: 20px; font-size: 0.75rem; font-weight: 700; border: 1px solid #fecaca; white-space: nowrap;">Từ chối</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (empty($leaves)): ?>
                <tr>
                    <td colspan="6" style="text-align: center; padding: 4rem; color: #94a3b8;">
                        <i class="fas fa-calendar-times fa-3x" style="opacity: 0.2; margin-bottom: 1rem; display: block;"></i>
                        Không tìm thấy đơn xin nghỉ phép nào.
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<script>
async function handleLeaveAction(id, action) {
    if (!confirm('Bạn có chắc chắn muốn ' + (action === 'approve' ? 'duyệt' : 'từ chối') + ' đơn này?')) return;
    try {
        const fd = new FormData();
        fd.append('action', action);
        fd.append('id', id);
        const r = await fetch('../../api/leave_requests.php', { method: 'POST', body: fd });
        const res = await r.json();
        if (res.success) { window.location.reload(); } 
        else { alert(res.message); }
    } catch(err) { alert("Lỗi hệ thống."); }
}
</script>

<?php require_once '../../templates/footer.php'; ?>
