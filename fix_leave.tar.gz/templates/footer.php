<?php
// templates/footer.php
?>
            </div> <!-- End content-body -->
        </main>
    </div> <!-- End app-container -->
    <?php include __DIR__ . '/tasks_drawer.php'; ?>
    <?php include __DIR__ . '/leave_modal.php'; ?>
    <script src="/assets/js/main.js"></script>
</body>
</html>
