<?php
// templates/leave_modal.php
require_once __DIR__ . '/../includes/db.php';
$db = getDB();
$active_users = $db->query("SELECT id, full_name, role_id FROM users WHERE status = 'active' ORDER BY full_name")->fetchAll();
?>

<!-- LEAVE MODAL (GLOBAL) -->
<div id="leaveModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(15,23,42,0.6); z-index: 1000; align-items: center; justify-content: center; backdrop-filter: blur(4px);">
    <div style="background: white; border-radius: 20px; box-shadow: 0 25px 50px -12px rgba(0,0,0,0.25); width: 100%; max-width: 500px; overflow: hidden; transform: scale(0.95); animation: modalIn 0.2s forwards;">
        <div style="padding: 1.5rem 2rem; border-bottom: 1px solid #f1f5f9; display: flex; justify-content: space-between; align-items: center;">
            <h3 style="margin: 0; font-weight: 800; font-size: 1.25rem; color: #1e293b;"><i class="fas fa-calendar-times text-warning"></i> Đơn Xin Nghỉ Phép</h3>
            <button onclick="document.getElementById('leaveModal').style.display='none'" style="background: none; border: none; color: #94a3b8; font-size: 1.2rem; cursor: pointer;"><i class="fas fa-times"></i></button>
        </div>
        <div style="padding: 2rem;">
            <form id="leaveForm" onsubmit="submitLeaveRequest(event)">
                <div class="form-group" style="margin-bottom: 1rem;">
                    <label class="form-label">Nhân sự nghỉ phép <span style="color: red;">*</span></label>
                    <select name="assigned_user_id" class="form-input" required>
                        <?php foreach ($active_users as $u): ?>
                            <option value="<?php echo $u['id']; ?>" <?php echo $u['id'] == $_SESSION['user_id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($u['full_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-bottom: 1rem;">
                    <div class="form-group">
                        <label class="form-label">Từ ngày <span style="color: red;">*</span></label>
                        <input type="date" name="start_date" id="leave_start" class="form-input" required min="<?php echo date('Y-m-d'); ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Đến ngày <span style="color: red;">*</span></label>
                        <input type="date" name="end_date" id="leave_end" class="form-input" required min="<?php echo date('Y-m-d'); ?>">
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label">Lý do nghỉ (Tuỳ chọn)</label>
                    <textarea name="reason" class="form-input" rows="3" placeholder="Nhập lý do..."></textarea>
                </div>
                <div style="background: #eff6ff; padding: 1rem; border-radius: 10px; margin-bottom: 1.5rem; display: flex; gap: 0.75rem; align-items: flex-start;">
                    <i class="fas fa-info-circle" style="color: #3b82f6; margin-top: 3px;"></i>
                    <p style="margin: 0; font-size: 0.85rem; color: #1e40af; line-height: 1.4;">
                        Hệ thống sẽ quét các <strong>Lịch hẹn Bệnh nhân</strong> của nhân sự này trong khoảng thời gian trên và tự báo cáo cho Bàn Lễ Tân thu xếp thay đổi.
                    </p>
                </div>
                <div style="display: flex; gap: 1rem; justify-content: flex-end;">
                    <button type="button" onclick="document.getElementById('leaveModal').style.display='none'" class="btn" style="background: #f1f5f9; color: #64748b;">Huỷ</button>
                    <button type="submit" id="btnSubmitLeave" class="btn btn-primary" style="font-weight: 700;"><i class="fas fa-paper-plane"></i> Gửi Đơn & Bàn Giao</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
async function submitLeaveRequest(e) {
    e.preventDefault();
    const btn = document.getElementById('btnSubmitLeave');
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Đang xử lý...';
    btn.disabled = true;

    const fd = new FormData(e.target);
    try {
        const r = await fetch('<?php echo isset($base_url) ? $base_url : "/"; ?>api/leave_requests.php', { method: 'POST', body: fd });
        const res = await r.json();
        
        if (res.success) {
            alert(res.message);
            document.getElementById('leaveModal').style.display = 'none';
            e.target.reset();
            window.location.reload();
        } else {
            alert(res.message);
        }
    } catch(err) {
        alert("Lỗi hệ thống khi gửi đơn.");
    } finally {
        btn.innerHTML = '<i class="fas fa-paper-plane"></i> Gửi Đơn & Bàn Giao';
        btn.disabled = false;
    }
}
</script>
