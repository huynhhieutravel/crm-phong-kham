<?php
// api/leave_requests.php
require_once '../includes/db.php';
require_once '../includes/functions.php';
require_once '../includes/auth_middleware.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$db = getDB();
$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['full_name'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? 'create';

    if ($action === 'approve' || $action === 'reject') {
        $allowed_roles = ['admin', 'doctor'];
        if (!isset($_SESSION['role']) || !in_array($_SESSION['role'], $allowed_roles)) {
            echo json_encode(['success' => false, 'message' => 'Bạn không có quyền duyệt quyền này.']);
            exit;
        }

        $id = (int)($_POST['id'] ?? 0);
        $new_status = ($action === 'approve') ? 'approved' : 'rejected';
        
        $stmt = $db->prepare("UPDATE leave_requests SET status = ? WHERE id = ?");
        if ($stmt->execute([$new_status, $id])) {
            echo json_encode(['success' => true, 'message' => 'Đã cập nhật trạng thái đơn!']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Lỗi cập nhật CSDL.']);
        }
        exit;
    }

    $start_date = $_POST['start_date'] ?? null;
    $end_date = $_POST['end_date'] ?? null;
    $reason = $_POST['reason'] ?? '';

    if (!$start_date || !$end_date) {
        echo json_encode(['success' => false, 'message' => 'Vui lòng chọn ngày']);
        exit;
    }

    $target_user_id = $_POST['assigned_user_id'] ?? $user_id;
    $target_user_name = $db->query("SELECT full_name FROM users WHERE id = " . (int)$target_user_id)->fetchColumn();

    try {
        $db->beginTransaction();

        // 1. Create Leave Request
        $stmtParams = [
            $target_user_id,
            $start_date,
            $end_date,
            $reason,
            'pending'
        ];
        $db->prepare("INSERT INTO leave_requests (user_id, start_date, end_date, reason, status) VALUES (?, ?, ?, ?, ?)")->execute($stmtParams);
        $leave_id = $db->lastInsertId();

        // 2. Check for overlapping appointments
        $stmt = $db->prepare("
            SELECT a.id, a.appointment_date, p.full_name as patient_name
            FROM appointments a
            LEFT JOIN patients p ON a.patient_id = p.id
            WHERE a.doctor_id = ? 
              AND a.status IN ('scheduled', 'confirmed')
              AND DATE(a.appointment_date) BETWEEN ? AND ?
        ");
        $stmt->execute([$target_user_id, $start_date, $end_date]);
        $conflicts = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // 3. Create Smart Tasks for each conflicting appointment
        if (count($conflicts) > 0) {
            // Find a receptionist or admin to assign these tasks to (role_id 1 is Admin, maybe 4 is Lễ tân)
            // Let's just create general tasks, or assign to admin (id = 1) for now if we can't find receptionist
            $rec_stmt = $db->query("SELECT id FROM users WHERE role_id = 4 AND status = 'active' LIMIT 1");
            $assign_to = $rec_stmt->fetchColumn() ?: 1; // Default to admin

            foreach ($conflicts as $c) {
                $apt_date = date('d/m/Y H:i', strtotime($c['appointment_date']));
                $title = "BÁO KHÁCH ĐỔI NHÂN SỰ: " . $c['patient_name'];
                $desc = "Nhân sự $target_user_name xin nghỉ từ $start_date đến $end_date.\nLịch của Bệnh nhân {$c['patient_name']} (Lúc: {$apt_date}) bị ảnh hưởng.\nVui lòng gọi điện dời lịch hoặc tìm Bác sĩ thay thế!";
                
                $db->prepare("INSERT INTO staff_tasks (user_id, created_by, title, description, due_date) VALUES (?, ?, ?, ?, ?)")
                   ->execute([$assign_to, $target_user_id, $title, $desc, $c['appointment_date']]);
            }
        }

        $db->commit();
        echo json_encode([
            'success' => true, 
            'conflict_count' => count($conflicts),
            'message' => 'Đã gửi đơn báo nghỉ! Hệ thống đã auto-generate ' . count($conflicts) . ' task nhắc nhở sửa lịch cho Lễ Tân.'
        ]);
        
    } catch (Exception $e) {
        $db->rollBack();
        echo json_encode(['success' => false, 'message' => 'Lỗi DB: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['error' => 'Invalid method']);
}
