<?php
// config/database.php

return [
    'host'     => '127.0.0.1',
    'dbname'   => 'clinic_management',
    'username' => 'crm_admin',
    'password' => 'CrmAdmin2026@Pass',
    'charset'  => 'utf8mb4'
];
