<?php
// modules/medical/chiro_exam.php
session_start();
require_once '../../includes/db.php';
require_once '../../includes/functions.php';
require_once '../../includes/auth_middleware.php';
require_permission('manage_medical');
require_once '../../includes/auth.php';

$patient_id = $_GET['patient_id'] ?? 0;
$session_id = $_GET['session_id'] ?? null;
$record_id = $_GET['id'] ?? null;
$db = getDB();

$existing_data = [];
if ($record_id) {
    $stmt = $db->prepare("SELECT history_data FROM medical_history WHERE id = ?");
    $stmt->execute([$record_id]);
    $json = $stmt->fetchColumn();
    $existing_data = json_decode($json, true) ?: [];
}
// Support for $history_id which might be used in some parts of the code
$history_id = $record_id;

function get_v($path, $default = '') {
    global $existing_data;
    $keys = explode('.', $path);
    $val = $existing_data;
    foreach ($keys as $key) {
        if (!isset($val[$key])) return $default;
        $val = $val[$key];
    }
    return $val;
}

function checked_v($path, $value) {
    $val = get_v($path);
    if (is_array($val)) return in_array($value, $val) ? 'checked' : '';
    return $val == $value ? 'checked' : '';
}

// 1. Fetch Session Status for Locking
$is_locked = false;
if ($session_id) {
    $stmt = $db->prepare("SELECT status, session_date FROM medical_sessions WHERE id = ?");
    $stmt->execute([$session_id]);
    $session = $stmt->fetch();
    if ($session && $session['status'] === 'completed' && !has_role('admin')) {
        $is_locked = true;
    }
}

// 2. Handle Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($is_locked) {
        set_flash(__('medical.exam.err_locked'), 'error');
        redirect("session_view.php?id=$session_id");
    }

    $exam = $_POST['exam'] ?? [];
    if (isset($exam['markers']) && is_string($exam['markers'])) {
        $exam['markers'] = json_decode($exam['markers'], true) ?: [];
    }
    $exam_data = json_encode($exam, JSON_UNESCAPED_UNICODE);
    
    if ($record_id) {
        // Fetch old data for audit
        $stmt_old = $db->prepare("SELECT history_data FROM medical_history WHERE id = ?");
        $stmt_old->execute([$record_id]);
        $old_json = $stmt_old->fetchColumn();
        
        $stmt = $db->prepare("UPDATE medical_history SET history_data = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?");
        $stmt->execute([$exam_data, $record_id]);
        
        log_audit($_SESSION['user_id'], 'update', 'medical_history', $record_id, json_decode($old_json, true), $exam);
    } else {
        $stmt = $db->prepare("
            INSERT INTO medical_history (patient_id, session_id, type, history_data, created_by)
            VALUES (?, ?, 'chiro_exam', ?, ?)
        ");
        $stmt->execute([$patient_id, $session_id, $exam_data, $_SESSION['user_id']]);
        $new_id = $db->lastInsertId();
        
        log_audit($_SESSION['user_id'], 'create', 'medical_history', $new_id, null, $exam);
    }
    
    set_flash(__('medical.exam.msg_success'));
    
    if ($session_id) {
        redirect("session_view.php?id=$session_id");
    } else {
        redirect("../patients/view.php?id=$patient_id");
    }
}

$stmt = $db->prepare("SELECT full_name FROM patients WHERE id = ?");
$stmt->execute([$patient_id]);
$patient_name = $stmt->fetchColumn();

if (!$patient_name) {
    set_flash(__('medical.exam.err_no_patient'), 'error');
    redirect('index.php');
}

$page_title = __('medical.type.chiro_exam_full');
$current_page = 'medical';
require_once '../../templates/header.php';

// Define Spine Nodes matching the text file
$spine_nodes = [
    __('medical.exam.spine_cervical') => [
        'C1' => 'Atlas', 
        'C2' => 'Axis 2', 
        'C3' => 'C3', 
        'C4' => 'C4', 
        'C5' => 'C5', 
        'C6' => 'C6', 
        'C7' => 'C7'
    ],
    __('medical.exam.spine_thoracic') => [
        'D1' => 'D1', 'D2' => 'D2', 'D3' => 'D3', 'D4' => 'D4', 'D5' => 'D5', 'D6' => 'D6',
        'D7' => 'D7', 'D8' => 'D8', 'D9' => 'D9', 'D10' => 'D10', 'D11' => 'D11', 'D12' => 'D12'
    ],
    __('medical.exam.spine_lumbar') => [
        'L1' => 'L1', 'L2' => 'L2', 'L3' => 'L3', 'L4' => 'L4', 'L5' => 'L5'
    ],
    __('medical.exam.spine_sacrum') => [
        'Sac' => __('medical.exam.spine_sacrum_label'), 
        'Coc' => __('medical.exam.spine_coccyx_label')
    ],
    __('medical.exam.spine_becken') => [
        'Rlli' => __('medical.exam.spine_p_ilium'), 
        'Llli' => __('medical.exam.spine_t_ilium')
    ]
];

$becken_nodes = ['AS', 'PI', 'IN-Ilium', 'EX-Ilium', 'Up-Slip', 'Down-Slip'];

$joint_nodes = [
    'Khớp vai' => __('medical.exam.joint_shoulder'),
    'Khớp khuỷu tay' => __('medical.exam.joint_elbow'),
    'Khớp cổ tay' => __('medical.exam.joint_wrist'),
    'Khớp háng' => __('medical.exam.joint_hip'),
    'Khớp gối' => __('medical.exam.joint_knee'),
    'Khớp cổ chân' => __('medical.exam.joint_ankle')
];
$markers = $existing_data['markers'] ?? [];
?>

    <style>
        .matrix-dot {
            display: inline-block;
            width: 32px;
            height: 32px;
            border: 2px solid #e2e8f0;
            border-radius: 6px;
            cursor: pointer;
            transition: all 0.2s;
            position: relative;
        }
        .matrix-dot input { position: absolute; opacity: 0; cursor: pointer; width: 100%; height: 100%; z-index: 2; }
        .matrix-dot span {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 100%;
            height: 100%;
            font-size: 0.75rem;
            font-weight: 800;
            color: #94a3b8;
        }
        .matrix-dot:has(input:checked) {
            background: #7c3aed;
            border-color: #7c3aed;
            box-shadow: 0 4px 10px rgba(124, 58, 237, 0.3);
        }
        .matrix-dot:has(input:checked) span { color: white; }
        .info-box {
            background: white;
            padding: 1.5rem;
            border-radius: 16px;
            border: 1px solid #eef2f6;
            box-shadow: 0 4px 15px -5px rgba(0,0,0,0.05);
        }
    </style>

    <div class="card" style="background: var(--glass-bg); backdrop-filter: blur(20px);">
        <div style="margin-bottom: 2rem; display: flex; justify-content: space-between; align-items: center;">
            <div>
                <h2 style="margin: 0; font-weight: 800; color: #7c3aed;"><i class="fas fa-stethoscope"></i> <?php echo __('medical.type.chiro_exam_full'); ?></h2>
                <p style="color: var(--text-muted); margin-top: 0.25rem;"><?php echo __('medical.exam.patient_label'); ?> <strong style="color: var(--text-main);"><?php echo e($patient_name); ?></strong></p>
            </div>
            <div style="background: #f5f3ff; color: #7c3aed; padding: 0.5rem 1.25rem; border-radius: 50px; font-weight: 700; font-size: 0.85rem; border: 1px solid #ddd6fe;">
                CHIR-PHYSICAL-EXAM
            </div>
        </div>

        <form method="POST">
            <?php if ($is_locked): ?>
                <div style="background: #fef2f2; color: #991b1b; padding: 1.25rem; border-radius: 20px; margin-bottom: 2rem; border: 1px solid #fecaca; display: flex; align-items: center; gap: 1rem; box-shadow: var(--premium-shadow);">
                    <i class="fas fa-lock fa-2x"></i>
                    <div>
                        <div style="font-weight: 800; font-size: 1rem;"><?php echo __('medical.exam.locked_title'); ?></div>
                        <div style="font-size: 0.85rem; font-weight: 600; opacity: 0.9;"><?php echo __('medical.exam.locked_desc'); ?></div>
                    </div>
                </div>
            <?php endif; ?>

            <fieldset <?php echo $is_locked ? 'disabled' : ''; ?> style="border: none; padding: 0; margin: 0;">
                <!-- 1. Spine Matrix -->
                <div style="margin-bottom: 3rem;">
                    <h3 style="font-size: 1.1rem; text-transform: uppercase; color: #7c3aed; margin-bottom: 1.5rem; display: flex; align-items: center; gap: 0.75rem;">
                        <i class="fas fa-bone"></i> <?php echo __('medical.exam.matrix_spine'); ?>
                    </h3>
                    
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 1.5rem; margin-bottom: 2rem;">
                        <?php foreach ($spine_nodes as $group => $nodes): ?>
                            <div class="info-box">
                                <h4 style="font-size: 0.85rem; text-align: center; color: #64748b; margin-top: 0; text-transform: uppercase; margin-bottom: 1rem; border-bottom: 1px solid #f1f5f9; padding-bottom: 0.5rem;"><?php echo $group; ?></h4>
                                <table style="width: 100%; border-collapse: collapse;">
                                    <thead>
                                        <tr style="font-size: 0.65rem; color: #94a3b8; text-align: center;">
                                            <th style="width: 30%;">L</th>
                                            <th style="width: 40%;"><?php echo __('medical.exam.spine_node'); ?></th>
                                            <th style="width: 30%;">R</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($nodes as $key => $label): ?>
                                            <tr>
                                                <td style="text-align: center; padding: 4px;">
                                                    <label class="matrix-dot">
                                                        <input type="checkbox" name="exam[spine][<?php echo $key; ?>][L]" value="1" <?php echo isset($existing_data['spine'][$key]['L']) ? 'checked' : ''; ?> class="spine-node" data-node="<?php echo $key; ?>">
                                                        <span>L</span>
                                                    </label>
                                                </td>
                                                <td style="text-align: center; font-weight: 800; font-size: 0.9rem; color: #1e293b;"><?php echo $label; ?></td>
                                                <td style="text-align: center; padding: 4px;">
                                                    <label class="matrix-dot">
                                                        <input type="checkbox" name="exam[spine][<?php echo $key; ?>][R]" value="1" <?php echo isset($existing_data['spine'][$key]['R']) ? 'checked' : ''; ?> class="spine-node" data-node="<?php echo $key; ?>">
                                                        <span>R</span>
                                                    </label>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 2rem;">
                        <!-- Becken section -->
                        <div class="info-box">
                            <h4 style="font-size: 0.9rem; margin-bottom: 1.5rem; color: #64748b; text-transform: uppercase; text-align: center; border-bottom: 1px solid #f1f5f9; padding-bottom: 0.5rem;">
                                <i class="fas fa-venus-mars"></i> <?php echo __('medical.exam.becken_area'); ?>
                            </h4>
                            <table style="width: 100%;">
                                <?php foreach ($becken_nodes as $node): ?>
                                    <tr>
                                        <td style="text-align: center; padding: 6px;">
                                            <label class="matrix-dot">
                                                <input type="checkbox" name="exam[becken][<?php echo $node; ?>][L]" value="1" <?php echo isset($existing_data['becken'][$node]['L']) ? 'checked' : ''; ?>>
                                                <span>L</span>
                                            </label>
                                        </td>
                                        <td style="text-align: center; font-weight: 700; font-size: 0.85rem; color: #334155;"><?php echo $node; ?></td>
                                        <td style="text-align: center; padding: 6px;">
                                            <label class="matrix-dot">
                                                <input type="checkbox" name="exam[becken][<?php echo $node; ?>][R]" value="1" <?php echo isset($existing_data['becken'][$node]['R']) ? 'checked' : ''; ?>>
                                                <span>R</span>
                                            </label>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </table>
                        </div>

                        <!-- Joints section -->
                        <div class="info-box">
                            <h4 style="font-size: 0.9rem; margin-bottom: 1.5rem; color: #64748b; text-transform: uppercase; text-align: center; border-bottom: 1px solid #f1f5f9; padding-bottom: 0.5rem;">
                                <i class="fas fa-joint"></i> <?php echo __('medical.exam.joints_area'); ?>
                            </h4>
                            <table style="width: 100%;">
                                        <?php foreach ($joint_nodes as $val => $label): ?>
                                            <tr>
                                                <td style="text-align: center; padding: 6px;">
                                                    <label class="matrix-dot">
                                                        <input type="checkbox" name="exam[joints][<?php echo $val; ?>][L]" value="1" <?php echo isset($existing_data['joints'][$val]['L']) ? 'checked' : ''; ?>>
                                                        <span>L</span>
                                                    </label>
                                                </td>
                                                <td style="text-align: center; font-weight: 700; font-size: 0.85rem; color: #334155;"><?php echo $label; ?></td>
                                                <td style="text-align: center; padding: 6px;">
                                                    <label class="matrix-dot">
                                                        <input type="checkbox" name="exam[joints][<?php echo $val; ?>][R]" value="1" <?php echo isset($existing_data['joints'][$val]['R']) ? 'checked' : ''; ?>>
                                                        <span>R</span>
                                                    </label>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- 2. Pain Marker section (Existing Logic) -->
                <div style="margin-bottom: 3rem;">
                    <h3 style="font-size: 1.1rem; text-transform: uppercase; color: #7c3aed; margin-bottom: 1.5rem; display: flex; align-items: center; gap: 0.75rem;">
                        <i class="fas fa-map-marker-alt"></i> <?php echo __('medical.exam.pain_map'); ?>
                    </h3>

                    <!-- Symptom Correlation Panel (NEW) -->
                    <div id="symptom-correlation" style="display: none; margin-bottom: 2rem; background: #f8fafc; border: 1px solid #e2e8f0; padding: 2rem; border-radius: 20px; box-shadow: var(--premium-shadow);">
                        <h4 style="margin: 0 0 1.5rem 0; font-size: 1rem; color: #1e293b; display: flex; align-items: center; gap: 0.75rem; text-transform: uppercase; letter-spacing: 0.5px; font-weight: 800;">
                            <i class="fas fa-microscope" style="color: #7c3aed;"></i> <?php echo __('medical.exam.symptom_table_title'); ?>
                        </h4>
                        <div id="symptom-list">
                            <!-- Symptoms will be injected here via JS -->
                        </div>
                    </div>

        <div style="margin-top: 3rem; display: flex; gap: 1rem; justify-content: flex-end;">
            <a href="session_view.php?id=<?php echo $session_id; ?>" class="btn" style="background: #f1f5f9; color: var(--text-main); padding: 1rem 2.5rem;"><?php echo __('common.back'); ?></a>
            <?php if (!$is_locked): ?>
                <button type="submit" class="btn btn-primary" style="padding: 1rem 3rem; font-weight: 700; font-size: 1.1rem;">
                    <i class="fas fa-save"></i> <?php echo __('medical.exam.btn_save'); ?>
                </button>
            <?php endif; ?>
        </div>
    </form>
</div>

<style>
.matrix-btn {
    display: inline-block;
    cursor: pointer;
    width: 44px;
    height: 44px;
}
.matrix-btn input { position: absolute; opacity: 0; }
.matrix-btn span {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 100%;
    height: 100%;
    background: white;
    border: 2px solid #e2e8f0;
    border-radius: 10px;
    font-weight: 700;
    color: #94a3b8;
    transition: all 0.2s;
}
.matrix-btn:hover span { border-color: var(--primary); color: var(--primary); }
.matrix-btn:has(input:checked) span {
    background: var(--primary);
    border-color: var(--primary);
    color: white;
    box-shadow: 0 4px 10px rgba(99, 102, 241, 0.3);
}

/* Marking Tool Styles */
.tool-btn {
    width: 44px;
    height: 44px;
    border-radius: 10px;
    border: 1px solid #e2e8f0;
    background: white;
    color: #64748b;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: all 0.2s;
    border: none;
}
.tool-btn.active {
    background: #eff6ff;
    border: 1px solid #3b82f6;
    color: #3b82f6;
}

.intensity-btn {
    border: 2px solid transparent;
    border-radius: 10px;
    padding: 0.5rem;
    background: white;
    cursor: pointer;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 4px;
    font-size: 0.65rem;
    font-weight: 800;
    transition: all 0.2s;
    width: 100%;
}
.intensity-btn span {
    width: 16px;
    height: 16px;
    border-radius: 50%;
}
.intensity-btn.active {
    background: #f8fafc;
    box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1);
    transform: translateY(-2px);
    border-color: currentColor;
}
</style>

<script src="../../assets/js/medical_marking.js"></script>
<script>
document.addEventListener('DOMContentLoaded', () => {
    new MedicalMarking(
        'exam-anatomy-canvas', 
        'exam-marking-data', 
        '../../assets/images/anatomy_4_views_clean.png'
    );
    updateSymptomPanel();
});

// Symptom Correlation Logic matching Text File/DOCX 100%
const symptomMap = {
    'C1': { organs: '<?php echo __('medical.exam.correlation_c1_organs'); ?>', symptoms: '<?php echo __('medical.exam.correlation_c1_symptoms'); ?>' },
    'C2': { organs: '<?php echo __('medical.exam.correlation_c2_organs'); ?>', symptoms: '<?php echo __('medical.exam.correlation_c2_symptoms'); ?>' },
    'C3': { organs: '<?php echo __('medical.exam.correlation_c3_organs'); ?>', symptoms: '<?php echo __('medical.exam.correlation_c3_symptoms'); ?>' },
    'C4': { organs: '<?php echo __('medical.exam.correlation_c4_organs'); ?>', symptoms: '<?php echo __('medical.exam.correlation_c4_symptoms'); ?>' },
    'C5': { organs: '<?php echo __('medical.exam.correlation_c5_organs'); ?>', symptoms: '<?php echo __('medical.exam.correlation_c5_symptoms'); ?>' },
    'C6': { organs: '<?php echo __('medical.exam.correlation_c6_organs'); ?>', symptoms: '<?php echo __('medical.exam.correlation_c6_symptoms'); ?>' },
    'C7': { organs: '<?php echo __('medical.exam.correlation_c7_organs'); ?>', symptoms: '<?php echo __('medical.exam.correlation_c7_symptoms'); ?>' },
    'D1': { organs: '<?php echo __('medical.exam.correlation_d1_organs'); ?>', symptoms: '<?php echo __('medical.exam.correlation_d1_symptoms'); ?>' },
    'D2': { organs: '<?php echo __('medical.exam.correlation_d2_organs'); ?>', symptoms: '<?php echo __('medical.exam.correlation_d2_symptoms'); ?>' },
    'D3': { organs: '<?php echo __('medical.exam.correlation_d3_organs'); ?>', symptoms: '<?php echo __('medical.exam.correlation_d3_symptoms'); ?>' },
    'D4': { organs: '<?php echo __('medical.exam.correlation_d4_organs'); ?>', symptoms: '<?php echo __('medical.exam.correlation_d4_symptoms'); ?>' },
    'D5': { organs: '<?php echo __('medical.exam.correlation_d5_organs'); ?>', symptoms: '<?php echo __('medical.exam.correlation_d5_symptoms'); ?>' },
    'D6': { organs: '<?php echo __('medical.exam.correlation_d6_organs'); ?>', symptoms: '<?php echo __('medical.exam.correlation_d6_symptoms'); ?>' },
    'D7': { organs: '<?php echo __('medical.exam.correlation_d7_organs'); ?>', symptoms: '<?php echo __('medical.exam.correlation_d7_symptoms'); ?>' },
    'D8': { organs: '<?php echo __('medical.exam.correlation_d8_organs'); ?>', symptoms: '<?php echo __('medical.exam.correlation_d8_symptoms'); ?>' },
    'D9': { organs: '<?php echo __('medical.exam.correlation_d9_organs'); ?>', symptoms: '<?php echo __('medical.exam.correlation_d9_symptoms'); ?>' },
    'D10': { organs: '<?php echo __('medical.exam.correlation_d10_organs'); ?>', symptoms: '<?php echo __('medical.exam.correlation_d10_symptoms'); ?>' },
    'D11': { organs: '<?php echo __('medical.exam.correlation_d11_organs'); ?>', symptoms: '<?php echo __('medical.exam.correlation_d11_symptoms'); ?>' },
    'D12': { organs: '<?php echo __('medical.exam.correlation_d12_organs'); ?>', symptoms: '<?php echo __('medical.exam.correlation_d12_symptoms'); ?>' },
    'L1': { organs: '<?php echo __('medical.exam.correlation_l1_organs'); ?>', symptoms: '<?php echo __('medical.exam.correlation_l1_symptoms'); ?>' },
    'L2': { organs: '<?php echo __('medical.exam.correlation_l2_organs'); ?>', symptoms: '<?php echo __('medical.exam.correlation_l2_symptoms'); ?>' },
    'L3': { organs: '<?php echo __('medical.exam.correlation_l3_organs'); ?>', symptoms: '<?php echo __('medical.exam.correlation_l3_symptoms'); ?>' },
    'L4': { organs: '<?php echo __('medical.exam.correlation_l4_organs'); ?>', symptoms: '<?php echo __('medical.exam.correlation_l4_symptoms'); ?>' },
    'L5': { organs: '<?php echo __('medical.exam.correlation_l5_organs'); ?>', symptoms: '<?php echo __('medical.exam.correlation_l5_symptoms'); ?>' },
    'Sac': { organs: '<?php echo __('medical.exam.correlation_sac_organs'); ?>', symptoms: '<?php echo __('medical.exam.correlation_sac_symptoms'); ?>' },
    'Coc': { organs: '<?php echo __('medical.exam.correlation_coc_organs'); ?>', symptoms: '<?php echo __('medical.exam.correlation_coc_symptoms'); ?>' }
};

document.querySelectorAll('.spine-node').forEach(node => {
    node.addEventListener('change', updateSymptomPanel);
});

function updateSymptomPanel() {
    const activeCheckboxes = Array.from(document.querySelectorAll('.spine-node:checked'));
    const panel = document.getElementById('symptom-correlation');
    const list = document.getElementById('symptom-list');
    
    if (activeCheckboxes.length > 0) {
        if(panel) panel.style.display = 'block';
        
        // Extract unique node info
        const selectedInfo = [];
        const seen = new Set();
        
        activeCheckboxes.forEach(cb => {
            const nodeId = cb.getAttribute('data-node');
            if (!seen.has(nodeId)) {
                seen.add(nodeId);
                const row = cb.closest('tr');
                const label = row ? row.querySelector('td:nth-child(2)').innerText : nodeId;
                selectedInfo.push({ id: nodeId, label: label });
            }
        });

        let tableHtml = `
            <div class="table-responsive" style="margin-top: 1rem;">
                <table class="premium-table-symptom">
                    <thead>
                        <tr>
                            <th style="width: 15%;"><?php echo __('medical.exam.symptom_node'); ?></th>
                            <th style="width: 35%;"><?php echo __('medical.exam.symptom_organ'); ?></th>
                            <th><?php echo __('medical.exam.symptom_issue'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
        `;

        selectedInfo.forEach(info => {
            const data = symptomMap[info.id];
            if (data) {
                tableHtml += `
                    <tr>
                        <td style="font-weight: 800; color: #7c3aed; text-align: center; vertical-align: middle;">${info.label}</td>
                        <td style="color: #475569; font-size: 0.85rem; vertical-align: middle;">${data.organs}</td>
                        <td style="color: #1e293b; font-weight: 600; font-size: 0.9rem; vertical-align: middle;">${data.symptoms}</td>
                    </tr>
                `;
            }
        });
        
        tableHtml += '</tbody></table></div>';
        if(list) list.innerHTML = tableHtml;
    } else {
        if(panel) panel.style.display = 'none';
        if(list) list.innerHTML = '';
    }
}
</script>

<style>
    .premium-table-symptom {
        width: 100%;
        border-collapse: separate;
        border-spacing: 0;
        background: white;
        border-radius: 12px;
        overflow: hidden;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
        border: 1px solid #e2e8f0;
    }
    .premium-table-symptom th {
        background: #f8fafc;
        padding: 1rem;
        font-size: 0.75rem;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        color: #64748b;
        border-bottom: 2px solid #e2e8f0;
        text-align: left;
    }
    .premium-table-symptom td {
        padding: 1rem;
        border-bottom: 1px solid #f1f5f9;
        line-height: 1.5;
    }
    .premium-table-symptom tr:last-child td {
        border-bottom: none;
    }
</style>

<?php require_once '../../templates/footer.php'; ?>
