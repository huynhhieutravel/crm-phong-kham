/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.6.23-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: clinic_management
-- ------------------------------------------------------
-- Server version	10.6.23-MariaDB-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `appointments`
--

DROP TABLE IF EXISTS `appointments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `appointments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `patient_id` int(11) DEFAULT NULL,
  `lead_id` int(11) DEFAULT NULL,
  `doctor_id` int(11) DEFAULT NULL,
  `type` enum('consultation','treatment','re_exam','adjustment') DEFAULT 'consultation',
  `reexam_rule_id` int(11) DEFAULT NULL,
  `branch_id` int(11) NOT NULL,
  `appointment_date` datetime NOT NULL,
  `status` enum('scheduled','confirmed','arrived','no_show','cancelled','completed') DEFAULT 'scheduled',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `duration` int(11) DEFAULT NULL COMMENT 'Duration in minutes',
  `appointment_end_time` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `patient_id` (`patient_id`),
  KEY `lead_id` (`lead_id`),
  KEY `doctor_id` (`doctor_id`),
  KEY `branch_id` (`branch_id`),
  CONSTRAINT `appointments_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `appointments_ibfk_2` FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`) ON DELETE SET NULL,
  CONSTRAINT `appointments_ibfk_3` FOREIGN KEY (`doctor_id`) REFERENCES `users` (`id`),
  CONSTRAINT `appointments_ibfk_4` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appointments`
--

LOCK TABLES `appointments` WRITE;
/*!40000 ALTER TABLE `appointments` DISABLE KEYS */;
INSERT INTO `appointments` VALUES (1,2,NULL,10,'re_exam',NULL,1,'2026-03-30 14:00:00','scheduled','','2026-03-27 03:15:24',NULL,'14:30:00'),(2,2,NULL,4,'consultation',NULL,1,'2026-03-30 14:30:00','scheduled','','2026-03-27 03:17:00',NULL,'16:00:00'),(3,10,NULL,4,'re_exam',NULL,1,'2026-04-01 08:30:00','scheduled','','2026-03-27 06:29:21',NULL,'10:00:00'),(4,21,NULL,5,'re_exam',NULL,1,'2026-03-28 14:00:00','scheduled','','2026-03-27 07:09:36',NULL,'15:00:00'),(5,21,NULL,5,'re_exam',NULL,1,'2026-03-29 14:00:00','scheduled','','2026-03-27 07:11:41',NULL,'15:00:00'),(6,22,NULL,8,'re_exam',NULL,1,'2026-03-28 14:00:00','scheduled','','2026-03-27 07:13:23',NULL,'15:00:00'),(7,22,NULL,4,'re_exam',NULL,1,'2026-03-29 14:00:00','scheduled','','2026-03-27 07:14:12',NULL,'15:00:00'),(8,37,NULL,8,'re_exam',NULL,1,'2026-03-29 09:30:00','scheduled','','2026-03-27 07:50:05',NULL,'11:00:00'),(9,40,NULL,9,'re_exam',NULL,1,'2026-03-28 08:30:00','scheduled','','2026-03-27 07:54:46',NULL,'09:00:00'),(10,40,NULL,4,'re_exam',NULL,1,'2026-03-28 09:00:00','scheduled','','2026-03-27 07:55:28',NULL,'10:30:00'),(11,42,NULL,8,'consultation',NULL,1,'2026-03-28 14:30:00','scheduled','','2026-03-27 07:58:35',NULL,'16:00:00'),(12,43,NULL,5,'re_exam',NULL,1,'2026-03-28 08:30:00','scheduled','','2026-03-27 08:02:31',NULL,'10:00:00'),(13,43,NULL,10,'re_exam',NULL,1,'2026-03-28 10:00:00','scheduled','','2026-03-27 08:02:59',NULL,'10:30:00'),(14,44,NULL,10,'re_exam',NULL,1,'2026-03-28 08:30:00','scheduled','','2026-03-27 08:05:49',NULL,'09:00:00'),(15,44,NULL,8,'re_exam',NULL,1,'2026-03-28 09:00:00','scheduled','','2026-03-27 08:06:42',NULL,'10:00:00'),(16,51,NULL,8,'re_exam',NULL,1,'2026-03-28 11:00:00','scheduled','','2026-03-27 08:29:56',NULL,'12:30:00'),(17,51,NULL,5,'re_exam',NULL,1,'2026-03-29 11:00:00','scheduled','','2026-03-27 08:30:33',NULL,'12:30:00'),(18,52,NULL,10,'re_exam',NULL,1,'2026-03-29 10:00:00','scheduled','','2026-03-27 08:33:25',NULL,'10:30:00'),(19,52,NULL,4,'re_exam',NULL,1,'2026-03-29 10:30:00','scheduled','','2026-03-27 08:33:55',NULL,'12:00:00'),(20,53,NULL,4,'re_exam',NULL,1,'2026-03-29 08:00:00','scheduled','','2026-03-27 08:38:06',NULL,'09:30:00'),(21,54,NULL,10,'treatment',NULL,1,'2026-03-28 09:00:00','scheduled','','2026-03-27 09:36:28',NULL,'09:30:00'),(22,55,NULL,10,'treatment',NULL,1,'2026-03-28 09:30:00','scheduled','','2026-03-27 09:37:33',NULL,NULL),(23,54,NULL,5,'treatment',NULL,1,'2026-03-28 09:30:00','scheduled','','2026-03-27 09:38:02',NULL,'11:00:00'),(24,55,NULL,8,'treatment',NULL,1,'2026-03-28 10:00:00','scheduled','','2026-03-27 09:38:45',NULL,'11:30:00'),(25,51,NULL,8,'re_exam',NULL,1,'2026-04-04 11:00:00','scheduled','','2026-03-27 09:45:58',NULL,'12:30:00'),(26,51,NULL,4,'re_exam',NULL,1,'2026-04-05 11:00:00','scheduled','','2026-03-27 09:46:28',NULL,'12:30:00');
/*!40000 ALTER TABLE `appointments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `action` varchar(50) NOT NULL,
  `target_table` varchar(50) NOT NULL,
  `target_id` int(11) NOT NULL,
  `old_data` longtext DEFAULT NULL,
  `new_data` longtext DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
INSERT INTO `audit_logs` VALUES (1,3,'create','medical_history',1,NULL,'{\"spine\":{\"C6\":{\"R\":\"1\"},\"C7\":{\"L\":\"1\"},\"D1\":{\"R\":\"1\"}}}','116.108.11.84','2026-03-27 03:22:52'),(2,1,'update','medical_sessions',1,'{\"assessment\":null,\"treatment_plan\":null,\"status\":\"active\"}','{\"assessment\":\"<p>Bệnh nhân đã được khám Chiro và Đông y buổi đầu tiên. Lúc đó chưa có app để nhập nên dữ liệu còn thiếu sót.<\\/p>\",\"treatment_plan\":\"<p>Lịch hẹn lần tới là 30.03.26<\\/p>\",\"status\":\"active\"}','116.108.11.84','2026-03-27 05:26:33');
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `branches`
--

DROP TABLE IF EXISTS `branches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `branches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `address` text DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `branches`
--

LOCK TABLES `branches` WRITE;
/*!40000 ALTER TABLE `branches` DISABLE KEYS */;
INSERT INTO `branches` VALUES (1,'Phòng khám Chính','Địa chỉ phòng khám','0123456789','2026-03-17 00:03:33');
/*!40000 ALTER TABLE `branches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_items`
--

DROP TABLE IF EXISTS `inventory_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `unit` varchar(20) NOT NULL COMMENT 'Gói, gram, cái...',
  `stock_quantity` decimal(10,2) DEFAULT 0.00,
  `min_stock` decimal(10,2) DEFAULT 0.00,
  `base_price` decimal(12,2) DEFAULT 0.00 COMMENT 'Giá nhập',
  `sell_price` decimal(12,2) DEFAULT 0.00 COMMENT 'Giá bán',
  `category` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_items`
--

LOCK TABLES `inventory_items` WRITE;
/*!40000 ALTER TABLE `inventory_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lead_logs`
--

DROP TABLE IF EXISTS `lead_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `lead_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lead_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `note` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_lead_id` (`lead_id`),
  KEY `fk_leadlogs_user` (`user_id`),
  CONSTRAINT `fk_leadlogs_lead` FOREIGN KEY (`lead_id`) REFERENCES `leads` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_leadlogs_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lead_logs`
--

LOCK TABLES `lead_logs` WRITE;
/*!40000 ALTER TABLE `lead_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `lead_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `leads`
--

DROP TABLE IF EXISTS `leads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `leads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(100) NOT NULL,
  `gender` enum('male','female','other') DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `zalo_number` varchar(20) DEFAULT NULL,
  `source` varchar(50) DEFAULT NULL COMMENT 'Nguồn: Facebook, Zalo, TikTok...',
  `medical_group` varchar(100) DEFAULT NULL COMMENT 'Nhóm bệnh: Cột sống, Xương khớp...',
  `consultant_id` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `status` enum('new','contacted','scheduled','converted','cancelled') DEFAULT 'new',
  `consultation_status` varchar(50) DEFAULT NULL,
  `contact_time` datetime DEFAULT NULL,
  `recontact_time` datetime DEFAULT NULL,
  `appointment_booking_time` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `branch_id` int(11) DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `phone` (`phone`),
  KEY `consultant_id` (`consultant_id`),
  CONSTRAINT `leads_ibfk_1` FOREIGN KEY (`consultant_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leads`
--

LOCK TABLES `leads` WRITE;
/*!40000 ALTER TABLE `leads` DISABLE KEYS */;
/*!40000 ALTER TABLE `leads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medical_history`
--

DROP TABLE IF EXISTS `medical_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `medical_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `patient_id` int(11) NOT NULL,
  `session_id` int(11) DEFAULT NULL,
  `type` varchar(50) NOT NULL,
  `history_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT 'Dữ liệu các câu hỏi tiền sử dạng checkbox/text' CHECK (json_valid(`history_data`)),
  `attachments` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Danh sách file hình ảnh X-quang, body scan...' CHECK (json_valid(`attachments`)),
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `patient_id` (`patient_id`),
  KEY `created_by` (`created_by`),
  KEY `fk_history_session` (`session_id`),
  CONSTRAINT `fk_history_session` FOREIGN KEY (`session_id`) REFERENCES `medical_sessions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `medical_history_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `medical_history_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medical_history`
--

LOCK TABLES `medical_history` WRITE;
/*!40000 ALTER TABLE `medical_history` DISABLE KEYS */;
INSERT INTO `medical_history` VALUES (1,2,1,'chiro_exam','{\"spine\":{\"C6\":{\"R\":\"1\"},\"C7\":{\"L\":\"1\"},\"D1\":{\"R\":\"1\"}}}',NULL,3,'2026-03-27 03:22:52','2026-03-27 03:22:52');
/*!40000 ALTER TABLE `medical_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medical_sessions`
--

DROP TABLE IF EXISTS `medical_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `medical_sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `patient_id` int(11) NOT NULL,
  `doctor_id` int(11) DEFAULT NULL,
  `appointment_id` int(11) DEFAULT NULL,
  `session_date` date NOT NULL,
  `assessment` text DEFAULT NULL,
  `treatment_plan` text DEFAULT NULL,
  `status` enum('active','completed') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_medical_sessions_patient` (`patient_id`),
  KEY `fk_medical_sessions_doctor` (`doctor_id`),
  KEY `fk_medical_sessions_appointment` (`appointment_id`),
  CONSTRAINT `fk_medical_sessions_appointment` FOREIGN KEY (`appointment_id`) REFERENCES `appointments` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_medical_sessions_doctor` FOREIGN KEY (`doctor_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_medical_sessions_patient` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ms_patient` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medical_sessions`
--

LOCK TABLES `medical_sessions` WRITE;
/*!40000 ALTER TABLE `medical_sessions` DISABLE KEYS */;
INSERT INTO `medical_sessions` VALUES (1,2,3,NULL,'2026-03-27','<p>Bệnh nhân đã được khám Chiro và Đông y buổi đầu tiên. Lúc đó chưa có app để nhập nên dữ liệu còn thiếu sót.</p>','<p>Lịch hẹn lần tới là 30.03.26</p>','active','2026-03-27 03:18:01','2026-03-27 05:26:33'),(2,23,1,NULL,'2026-03-27',NULL,NULL,'active','2026-03-27 07:35:38','2026-03-27 07:35:38'),(3,30,3,NULL,'2026-03-27',NULL,NULL,'active','2026-03-27 09:46:42','2026-03-27 09:46:42');
/*!40000 ALTER TABLE `medical_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `package_usage_logs`
--

DROP TABLE IF EXISTS `package_usage_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `package_usage_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `patient_package_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL COMMENT 'Người thực tế sử dụng buổi này',
  `treatment_id` int(11) NOT NULL,
  `used_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `patient_package_id` (`patient_package_id`),
  KEY `patient_id` (`patient_id`),
  KEY `treatment_id` (`treatment_id`),
  CONSTRAINT `package_usage_logs_ibfk_1` FOREIGN KEY (`patient_package_id`) REFERENCES `patient_packages` (`id`),
  CONSTRAINT `package_usage_logs_ibfk_2` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`),
  CONSTRAINT `package_usage_logs_ibfk_3` FOREIGN KEY (`treatment_id`) REFERENCES `treatments` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `package_usage_logs`
--

LOCK TABLES `package_usage_logs` WRITE;
/*!40000 ALTER TABLE `package_usage_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `package_usage_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `packages`
--

DROP TABLE IF EXISTS `packages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `packages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `total_sessions` int(11) NOT NULL COMMENT 'Số buổi trong gói',
  `total_price` decimal(12,2) NOT NULL,
  `is_corporate` tinyint(1) DEFAULT 0 COMMENT 'Gói cho công ty/nhóm',
  `valid_days` int(11) DEFAULT 365 COMMENT 'Hạn sử dụng',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `packages`
--

LOCK TABLES `packages` WRITE;
/*!40000 ALTER TABLE `packages` DISABLE KEYS */;
INSERT INTO `packages` VALUES (1,'Gói hỗn hợp Chiro/ Đông y',11,-9000000.00,1,365),(2,'Gói đông y 60',11,6000000.00,1,365),(3,'Gói test',3,2700000.00,0,365),(4,'Gói Chỉro basic',3,2700000.00,0,365);
/*!40000 ALTER TABLE `packages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patient_packages`
--

DROP TABLE IF EXISTS `patient_packages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `patient_packages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `patient_id` int(11) NOT NULL COMMENT 'Chủ gói (hoặc đại diện công ty)',
  `package_id` int(11) NOT NULL,
  `total_amount` decimal(12,2) NOT NULL,
  `paid_amount` decimal(12,2) DEFAULT 0.00,
  `sessions_remaining` int(11) NOT NULL,
  `status` enum('active','exhausted','expired') DEFAULT 'active',
  `purchase_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `expire_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `patient_id` (`patient_id`),
  KEY `package_id` (`package_id`),
  CONSTRAINT `patient_packages_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`),
  CONSTRAINT `patient_packages_ibfk_2` FOREIGN KEY (`package_id`) REFERENCES `packages` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient_packages`
--

LOCK TABLES `patient_packages` WRITE;
/*!40000 ALTER TABLE `patient_packages` DISABLE KEYS */;
/*!40000 ALTER TABLE `patient_packages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patients`
--

DROP TABLE IF EXISTS `patients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `patients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` varchar(50) DEFAULT NULL,
  `full_name` varchar(100) NOT NULL,
  `gender` enum('male','female','other') DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `zalo_number` varchar(20) DEFAULT NULL,
  `label` varchar(50) DEFAULT 'Khách mới',
  `source` varchar(50) DEFAULT NULL COMMENT 'Nguồn: Facebook, Zalo, Giới thiệu...',
  `notes` text DEFAULT NULL,
  `facebook_link` varchar(255) DEFAULT NULL,
  `instagram_link` varchar(255) DEFAULT NULL,
  `twitter_link` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `branch` varchar(50) DEFAULT NULL,
  `occupation` varchar(100) DEFAULT NULL,
  `guardian_name` varchar(100) DEFAULT NULL,
  `guardian_id_card` varchar(20) DEFAULT NULL,
  `guardian_phone` varchar(20) DEFAULT NULL,
  `guardian_relationship` varchar(50) DEFAULT NULL,
  `district` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `medical_history` text DEFAULT NULL,
  `consultant_id` int(11) DEFAULT NULL,
  `branch_id` int(11) DEFAULT 1,
  `lead_id` int(11) DEFAULT NULL,
  `personal_notes` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `phone` (`phone`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patients`
--

LOCK TABLES `patients` WRITE;
/*!40000 ALTER TABLE `patients` DISABLE KEYS */;
INSERT INTO `patients` VALUES (1,NULL,'Kiều Thị Kim Lan','female',NULL,'0903809719','','','','Hoa Nghiêm','Referral','','','','','2026-03-27 03:01:26','Trụ sở chính','Nghỉ hưu','','','','',NULL,NULL,NULL,3,1,NULL,''),(2,NULL,'Nguyễn Giáng Hương','female','1981-09-22','0939332263','','','','','Referral','','','','','2026-03-27 03:13:37','Trụ sở chính','NV Văn phòng','','','','',NULL,NULL,NULL,2,1,NULL,''),(3,NULL,'Huỳnh Thị Mai Trinh','female','1983-06-07','0908770330','','','','','Referral','','','','','2026-03-27 06:13:21','Trụ sở chính','Nhân Viên Văn phòng','','','','',NULL,NULL,NULL,3,1,NULL,''),(4,NULL,'Vũ Phước Thiện','male','2002-03-26','0815331639','','','','','Walk-in','','','','','2026-03-27 06:15:51','Trụ sở chính','Nhân Viên Văn phòng','','','','',NULL,NULL,NULL,NULL,1,NULL,''),(5,NULL,'Nguyễn Văn Hải','male','1979-04-20','0931456677','','','','','Referral','','','','','2026-03-27 06:18:47','Trụ sở chính','Kinh doanh','','','','',NULL,NULL,NULL,3,1,NULL,''),(6,NULL,'Nguyễn Thị Hồng Ngọc','female',NULL,'0907270393','','','','','Referral','','','','','2026-03-27 06:20:17','Trụ sở chính','Nhân Viên Văn phòng','','','','',NULL,NULL,NULL,NULL,1,NULL,''),(7,NULL,'Hồ Thị Thanh Dung','female','1979-03-27','0908159939','','','','','Referral','','','','','2026-03-27 06:22:11','Trụ sở chính','Nhân Viên Văn phòng','','','','',NULL,NULL,NULL,NULL,1,NULL,''),(8,NULL,'Nguyễn Thanh Hải','male','1963-12-22','1111111111','','','','','Referral','','','','','2026-03-27 06:23:40','Trụ sở chính','Tài xế','','','','',NULL,NULL,NULL,NULL,1,NULL,''),(9,NULL,'Trương Thị Mỹ Hương','female','1961-03-06','0903629727','','','','','Referral','','','','','2026-03-27 06:25:13','Trụ sở chính','','','','','',NULL,NULL,NULL,NULL,1,NULL,''),(10,NULL,'Cù Thu Hương','female','1963-03-18','0938767657','','','','','Referral','','','','','2026-03-27 06:28:16','Trụ sở chính','Chuyên gia tâm lý','','','','',NULL,NULL,NULL,NULL,1,NULL,''),(11,NULL,'Phạm Thị Hồng Hạnh','female','1988-10-03','0965657811','','','','','Referral','','','','','2026-03-27 06:32:49','Trụ sở chính','','','','','',NULL,NULL,NULL,NULL,1,NULL,''),(12,NULL,'Nguyễn Thùy Linh','female','1980-01-01','0919289589','','  A2.08.02 Hoàng Anh Gold House, xã Phước Kiển, Huyện Nhà Bè, Tp. Hồ Chí Minh','','','Referral','','','','','2026-03-27 06:34:10','Trụ sở chính','Nhân Viên Văn phòng','','','','',NULL,NULL,NULL,NULL,1,NULL,''),(13,NULL,'Nguyễn Văn Uấn','male','1963-01-01','0913925931','','','','','Referral','','','','','2026-03-27 06:47:12','Trụ sở chính','','','','','',NULL,NULL,NULL,NULL,1,NULL,''),(14,NULL,'Nguyễn Thị Ngọc Sương','female','1943-01-01','111111111','','','','','Referral','','','','','2026-03-27 06:48:23','Trụ sở chính','','','','','',NULL,NULL,NULL,NULL,1,NULL,''),(15,NULL,'Mai Thụy Nhân','male','1981-01-01','1111111111','','','','','Referral','','','','','2026-03-27 06:49:17','Trụ sở chính','','','','','',NULL,NULL,NULL,NULL,1,NULL,''),(16,NULL,'Nguyễn Xuân Hiền','male','1954-07-11','1111111111','','Hoa Kỳ','','','Referral','','','','','2026-03-27 06:55:11','Trụ sở chính','Nghỉ Hưu','','','','',NULL,NULL,NULL,NULL,1,NULL,''),(17,NULL,'Phạm Thu Hằng','female','1984-11-19','0948286686','','Hà Nội','','','Referral','','','','','2026-03-27 06:56:33','Trụ sở chính','','','','','',NULL,NULL,NULL,NULL,1,NULL,''),(18,NULL,'Nguyễn Thị Thủy','female',NULL,'0582366361','','','','','Chương Trình','','','','','2026-03-27 07:03:02','Trụ sở chính','Nhân Viên Văn phòng','','','','',NULL,NULL,NULL,NULL,1,NULL,''),(19,NULL,'Nguyễn Tuyết Sơn','female','1985-10-23','0922018718','','','','','Chương Trình','','','','','2026-03-27 07:04:49','Trụ sở chính','','','','','',NULL,NULL,NULL,NULL,1,NULL,''),(20,NULL,'Nguyễn Nhật Minh','male','2010-04-08','0983266626','','','','','Referral','','','','','2026-03-27 07:07:42','Trụ sở chính','','','','','',NULL,NULL,NULL,11,1,NULL,''),(21,NULL,'Võ Thị Thanh Thanh','female','1983-11-23','0909156488','','','','','Chương Trình','','','','','2026-03-27 07:08:38','Trụ sở chính','','','','','',NULL,NULL,NULL,NULL,1,NULL,''),(22,NULL,'Trần Thị Thu Thảo','female','1992-11-12','0985967452','','','','','Chương Trình','','','','','2026-03-27 07:12:40','Trụ sở chính','','','','','',NULL,NULL,NULL,NULL,1,NULL,''),(23,NULL,'Lê Thị Chiến Thắng','female','1973-05-07','0915416199','','','','','Facebook','','','','','2026-03-27 07:16:07','Trụ sở chính','','','','','',NULL,NULL,NULL,NULL,1,NULL,''),(24,NULL,'Nguyễn Thị Hương','female','1965-01-24','1111111111','','','','','Facebook','','','','','2026-03-27 07:28:01','Trụ sở chính','','','','','',NULL,NULL,NULL,NULL,1,NULL,''),(25,NULL,'Nguyễn Uyên Thi','female','1988-10-24','0918726931','','','','','Referral','','','','','2026-03-27 07:29:09','Trụ sở chính','','','','','',NULL,NULL,NULL,NULL,1,NULL,''),(26,NULL,'Louisa Nguyen Vẻrduron','female','1992-06-30','11111111111','','','','','Referral','','','','','2026-03-27 07:30:34','Trụ sở chính','','','','','',NULL,NULL,NULL,NULL,1,NULL,''),(27,NULL,'Nguyễn Thị Hồng Tuyết','female','1961-01-01','111111111','','','','','Facebook','','','','','2026-03-27 07:31:14','Trụ sở chính','','','','','',NULL,NULL,NULL,NULL,1,NULL,''),(28,NULL,'Đặng Thị Hoa Mai','female','1971-01-01','0909666777','','','','','Referral','','','','','2026-03-27 07:32:13','Trụ sở chính','','','','','',NULL,NULL,NULL,NULL,1,NULL,''),(29,NULL,'Ngô Khánh Chi','female','1982-09-06','0948225669','','','','','Referral','','','','','2026-03-27 07:33:42','Trụ sở chính','','','','','',NULL,NULL,NULL,NULL,1,NULL,''),(30,NULL,'Châu Huỳnh Thanh Cường','male','1977-01-01','1111111111','','Hoa Kỳ','','','Referral','','','','','2026-03-27 07:36:02','Trụ sở chính','','','','','',NULL,NULL,NULL,NULL,1,NULL,''),(31,NULL,'Nguyễn Thị Lệ Hằng','female','1987-12-09','0987891288','','','','','Referral','','','','','2026-03-27 07:38:57','Trụ sở chính','','','','','',NULL,NULL,NULL,NULL,1,NULL,''),(32,NULL,'Nguyễn Thế Tân','male','1983-12-13','0984 977 774','','6.2 Lầu 6 D2 Chung Cư Tam Phú, Cay Keo, Phường Tam Bình, Tp. HCM','','','Referral','','','','','2026-03-27 07:40:42','Trụ sở chính','','','','','',NULL,NULL,NULL,NULL,1,NULL,''),(33,NULL,'Nguyễn Thị Tuyết  ','female','1988-04-06','0973 026 732','','6.2 Lầu 6 D2 Chung Cư Tam Phú, Cay Keo, Phường Tam Bình, Tp. HCM','','','Facebook','','','','','2026-03-27 07:42:19','Trụ sở chính','','','','','',NULL,NULL,NULL,NULL,1,NULL,''),(34,NULL,'Nguyễn Thị Kim Vân ','female','1980-10-06','0909 848 752','',' 12/7A Đường P, Mỹ Tú 2, Phường Tân Hưng, Tp. Hồ Chí Minh','','','Facebook','','','','','2026-03-27 07:43:20','Trụ sở chính','','','','','',NULL,NULL,NULL,NULL,1,NULL,''),(35,NULL,'Văn Hồ Đông Phương','female','1980-06-27','0908281893','','585/32/16 Huỳnh Tấn Phát, Phường Tân Thuận, TP. Hồ Chí Minh','','','Referral','','','','','2026-03-27 07:45:17','Trụ sở chính','','','','','',NULL,NULL,NULL,NULL,1,NULL,''),(36,NULL,'Trần Sơn Hải','male','1970-03-20','0911693888','','','','','Referral','','','','','2026-03-27 07:48:05','Trụ sở chính','','','','','',NULL,NULL,NULL,NULL,1,NULL,''),(37,NULL,'Phạm Thị Thủy','female','1982-08-07','0989990974','','281/2/18 Bình Lợi, Phường Bình Lợi Trung, Tp. Hồ Chí Minh','','','Facebook','','','','','2026-03-27 07:49:08','Trụ sở chính','','','','','',NULL,NULL,NULL,NULL,1,NULL,''),(38,NULL,'Phạm Thị Xuân Hương','female','1962-03-04','0903877982','','343/12 Đường D5 Văn Thánh Bắc, Phường 25, Bình Thạnh, Tp. HCM','','','Facebook','','','','','2026-03-27 07:52:20','Trụ sở chính','','','','','',NULL,NULL,NULL,NULL,1,NULL,''),(39,NULL,'Thảo Đan','female','1996-01-01','0969035789','','','','','Referral','','','','','2026-03-27 07:53:08','Trụ sở chính','','','','','',NULL,NULL,NULL,NULL,1,NULL,''),(40,NULL,'Nguyễn Thị Tâm Hạnh','female','1975-01-01','0919087910','','','','HSC','Referral','','','','','2026-03-27 07:54:18','Trụ sở chính','','','','','',NULL,NULL,NULL,NULL,1,NULL,''),(41,NULL,'Võ Quỳnh Trang','female','1980-01-01','0988889399','','','','Hoa Nghiêm','Referral','','','','','2026-03-27 07:56:53','Trụ sở chính','','','','','',NULL,NULL,NULL,NULL,1,NULL,''),(42,NULL,'Nguyễn Thị Thu Phụng','female','1980-01-01','0989442248','','','','','Referral','','','','','2026-03-27 07:58:04','Trụ sở chính','','','','','',NULL,NULL,NULL,NULL,1,NULL,''),(43,NULL,'Lê Thị Kim Anh','female','1979-07-20','0916007326','','','','','Facebook','','','','','2026-03-27 08:01:55','Trụ sở chính','','','','','',NULL,NULL,NULL,NULL,1,NULL,''),(44,NULL,'Nguyễn Hoàng Dương','male','2004-01-01','0823461777','','','','','Referral','','','','','2026-03-27 08:05:28','Trụ sở chính','','','','','',NULL,NULL,NULL,NULL,1,NULL,''),(45,NULL,'Đinh Quốc Việt  ','male','1986-07-23','0938 987 468','','343/12 Đường D5, Phường Thạnh Mỹ Tây, Tp. Hồ Chí Minh','','ACB','Referral','','','','','2026-03-27 08:17:35','Trụ sở chính','','','','','',NULL,NULL,NULL,NULL,1,NULL,''),(46,NULL,'ĐOÀN KIM HOÀNG YẾN','female','1984-01-01','0985422095','','63A Điện Biên Phủ, Phường Gia Định, TP. Hồ Chí Minh','','','Facebook','','','','','2026-03-27 08:18:30','Trụ sở chính','','','','','',NULL,NULL,NULL,NULL,1,NULL,''),(47,NULL,'Dương Thị Xuân Hoà','female','1985-01-01',' 0909873846','',' 128 Bùi Tá Hán, Phường Bình Trưng, Tp. Hồ Chí Minh','','ACB','Facebook','','','','','2026-03-27 08:19:38','Trụ sở chính','','','','','',NULL,NULL,NULL,NULL,1,NULL,''),(48,NULL,'Ngô Thị Hiền	','female','1967-12-17',' 0986974438','',' 8/8 Đường 1, Phường Bình Trưng, TP. HCM','','','Facebook','','','','','2026-03-27 08:20:55','Trụ sở chính','','','','','',NULL,NULL,NULL,NULL,1,NULL,''),(49,NULL,'Nguyễn Thị Thu Hiền','female','1985-09-17','0902720409','','4.02 Chung cư An Hòa, Số 60 Trần Lựu, P. Bình Trưng, Tp. HCM','','','Facebook','','','','','2026-03-27 08:22:12','Trụ sở chính','','','','','',NULL,NULL,NULL,NULL,1,NULL,''),(50,NULL,'Phan Hoàng Tân','male','1957-01-01','0902858510','','','','','Facebook','','','','','2026-03-27 08:28:07','Trụ sở chính','','','','','',NULL,NULL,NULL,NULL,1,NULL,''),(51,NULL,'Nguyễn Đình Văn','male','1960-06-01','0903052036','','','','','Facebook','','','','','2026-03-27 08:29:22','Trụ sở chính','','','','','',NULL,NULL,NULL,NULL,1,NULL,''),(52,NULL,'Đặng Quốc Ân','male','2004-06-03','0768386999','','','','','Referral','','','','','2026-03-27 08:32:52','Trụ sở chính','','','','','',NULL,NULL,NULL,NULL,1,NULL,''),(53,NULL,'Chị Khánh Texgiang','female','1976-01-01','1111111111','','','','Tex Giang','Referral','','','','','2026-03-27 08:37:40','Trụ sở chính','','','','','',NULL,NULL,NULL,NULL,1,NULL,''),(54,NULL,'Đinh Hằng','female','1976-01-01','1111111111','','','','','Referral','','','','','2026-03-27 09:36:04','Trụ sở chính','','','','','',NULL,NULL,NULL,NULL,1,NULL,''),(55,NULL,'TRÚC','male','1976-01-01','1111111111','','','','','Referral','','','','','2026-03-27 09:37:10','Trụ sở chính','','','','','',NULL,NULL,NULL,NULL,1,NULL,'');
/*!40000 ALTER TABLE `patients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permission_key` varchar(50) NOT NULL,
  `description` varchar(200) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `permission_key` (`permission_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reexam_rules`
--

DROP TABLE IF EXISTS `reexam_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `reexam_rules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `patient_id` int(11) NOT NULL,
  `service_name` varchar(100) DEFAULT NULL,
  `frequency` int(11) DEFAULT NULL COMMENT 'Số ngày giữa mỗi lần tái khám',
  `next_due_at` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `patient_id` (`patient_id`),
  CONSTRAINT `reexam_rules_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reexam_rules`
--

LOCK TABLES `reexam_rules` WRITE;
/*!40000 ALTER TABLE `reexam_rules` DISABLE KEYS */;
/*!40000 ALTER TABLE `reexam_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_permissions`
--

DROP TABLE IF EXISTS `role_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_role_perm` (`role_id`,`permission_id`),
  KEY `permission_id` (`permission_id`),
  CONSTRAINT `role_permissions_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_permissions_ibfk_2` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_permissions`
--

LOCK TABLES `role_permissions` WRITE;
/*!40000 ALTER TABLE `role_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `role_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `display_name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'admin','Administrator'),(2,'doctor','Bác sĩ'),(3,'technician','Kỹ thuật viên'),(4,'receptionist','Lễ tân'),(5,'accountant','Kế toán'),(6,'cskh','Chăm sóc khách hàng'),(7,'manager','Quản lý');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `services`
--

DROP TABLE IF EXISTS `services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `price` decimal(12,2) NOT NULL,
  `category` enum('chiropractic','dong_y','other') NOT NULL,
  `description` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `services`
--

LOCK TABLES `services` WRITE;
/*!40000 ALTER TABLE `services` DISABLE KEYS */;
/*!40000 ALTER TABLE `services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `timekeeping`
--

DROP TABLE IF EXISTS `timekeeping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `timekeeping` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `check_in` datetime NOT NULL,
  `check_out` datetime DEFAULT NULL,
  `work_date` date NOT NULL,
  `shift` enum('morning','afternoon','full') DEFAULT 'full',
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `timekeeping_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `timekeeping`
--

LOCK TABLES `timekeeping` WRITE;
/*!40000 ALTER TABLE `timekeeping` DISABLE KEYS */;
INSERT INTO `timekeeping` VALUES (1,1,'2026-03-27 12:11:46',NULL,'2026-03-27','full',NULL);
/*!40000 ALTER TABLE `timekeeping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` enum('income','expense') NOT NULL,
  `category` varchar(50) NOT NULL COMMENT 'Dịch vụ, Gói, Bán hàng, Nhập kho, Lương...',
  `amount` decimal(12,2) NOT NULL,
  `reference_id` int(11) DEFAULT NULL COMMENT 'Link tới treatment_id, patient_package_id, v.v.',
  `description` text DEFAULT NULL,
  `branch_id` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `transaction_date` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `branch_id` (`branch_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `transactions_ibfk_1` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`),
  CONSTRAINT `transactions_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactions`
--

LOCK TABLES `transactions` WRITE;
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `treatments`
--

DROP TABLE IF EXISTS `treatments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `treatments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `patient_id` int(11) NOT NULL,
  `technician_id` int(11) NOT NULL COMMENT 'KTV thực hiện',
  `service_id` int(11) DEFAULT NULL,
  `package_id` int(11) DEFAULT NULL COMMENT 'Nếu dùng gói thì link tới đây',
  `session_data` text DEFAULT NULL COMMENT 'Ghi chú chi tiết buổi điều trị',
  `photo_before` varchar(255) DEFAULT NULL,
  `photo_after` varchar(255) DEFAULT NULL,
  `treatment_date` datetime DEFAULT current_timestamp(),
  `session_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `patient_id` (`patient_id`),
  KEY `technician_id` (`technician_id`),
  KEY `treatment_date` (`treatment_date`),
  CONSTRAINT `treatments_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `treatments_ibfk_2` FOREIGN KEY (`technician_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `treatments`
--

LOCK TABLES `treatments` WRITE;
/*!40000 ALTER TABLE `treatments` DISABLE KEYS */;
/*!40000 ALTER TABLE `treatments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `role_id` int(11) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `sort_order` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `role_id` (`role_id`),
  KEY `branch_id` (`branch_id`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`),
  CONSTRAINT `users_ibfk_2` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin.huy','$2y$10$KrQULg28iGWz6zaan3OoJOk2EA9VgntjDbn0BYCIzh2EvY2E5qEei','Admin Huy',NULL,NULL,1,NULL,'active','2026-03-26 09:30:17',0),(2,'admin','$2y$10$PyOrII2WwmHbfdZE4roTkeNuwQ7Xaj0FsUsyCsvTrm7Rlg0kxqSLO','System Admin',NULL,NULL,1,NULL,'active','2026-03-26 09:30:17',0),(3,'admin.simon','$2y$10$hpi9tZpkvURQaJKR.SDmVuplqsLis/S.PtkX0dOukQPnHTGIRUPB2','Simon Admin',NULL,NULL,1,NULL,'active','2026-03-26 09:30:17',0),(4,'loc','$2y$10$BC1uICpo9R4fnePV5KLMVeBdDh4cToAN6ZBCsIPRDpousA3agDQyC','Bùi Thị Lộc',NULL,NULL,2,1,'active','2026-03-27 03:04:54',3),(5,'Hạnh','$2y$10$Lf6kog.p1gr/5VLDeZoUnOmBdC5zr1xYHdj70kJKo.L1jkjrXDyHm','Phan Văn Hạnh',NULL,NULL,2,1,'active','2026-03-27 03:05:46',7),(6,'Henrik','$2y$10$Ao.FtY0mtZgyTWKw2e9wluMTjLnIfAS5Jc3uaCvKi2X3aJkfUnDgq','Henrik Simon',NULL,NULL,2,1,'active','2026-03-27 03:06:36',6),(7,'thuong','$2y$10$r8J1jYzR2uwkCh38dKALF.NY5qhUj0B3gDAoeBKiUwtDZjL4IYDSC','Nguyễn Thương',NULL,NULL,2,1,'active','2026-03-27 03:08:01',5),(8,'Nga','$2y$10$BAMp/wk6TQvydrQt13VRpenLCUhwXoK.aMdNyZEoLIU6hXHLzDKhu','Bùi Thị Nga',NULL,NULL,2,1,'active','2026-03-27 03:08:30',2),(9,'huy','$2y$10$ZPx1S6su7t.7mqW/uIPgSODAsLbsjTaEsvUEgKruos9o0mYPBDM6e','Bui Huy',NULL,NULL,2,1,'active','2026-03-27 03:09:05',1),(10,'johanna','$2y$10$XukAGlntbuw8ql1yjp4qT.lMsQBOU6C8jVd8f4NuU2zkrMfucVFPe','Johanna Mihm',NULL,NULL,2,1,'active','2026-03-27 03:09:29',4),(11,'phuong','$2y$10$gUUPnDn/Uu.SqW/mDvJibOsGaj3PkS5yF1C2LbS2i4xe2Ual5gUHy','Nguyễn Phương',NULL,NULL,1,1,'active','2026-03-27 07:33:00',0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vouchers`
--

DROP TABLE IF EXISTS `vouchers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `vouchers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL,
  `discount_type` enum('percent','amount') NOT NULL,
  `discount_value` decimal(12,2) NOT NULL,
  `min_spend` decimal(12,2) DEFAULT 0.00,
  `expire_date` date DEFAULT NULL,
  `usage_limit` int(11) DEFAULT 1,
  `used_count` int(11) DEFAULT 0,
  `status` enum('active','inactive') DEFAULT 'active',
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vouchers`
--

LOCK TABLES `vouchers` WRITE;
/*!40000 ALTER TABLE `vouchers` DISABLE KEYS */;
/*!40000 ALTER TABLE `vouchers` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-03-27 18:26:16
