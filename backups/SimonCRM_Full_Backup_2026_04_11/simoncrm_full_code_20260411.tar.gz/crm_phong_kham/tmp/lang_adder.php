<?php
// Script shortcut to append keys to language dicts
$input = file_get_contents('php://stdin');
if (!$input) {
    die("No input\n");
}
$keys = json_decode($input, true);
if (!$keys) {
    die("Invalid JSON\n");
}

$langs = ['vi', 'en', 'de', 'zh'];
$base_dir = realpath(__DIR__ . '/../lang');

foreach ($langs as $lang) {
    if (!isset($keys[$lang])) continue;
    $file = $base_dir . "/{$lang}.php";
    if (!file_exists($file)) continue;
    
    $content = file_get_contents($file);
    $insert = "";
    foreach ($keys[$lang] as $k => $v) {
        // Skip if key already exists visually
        if (strpos($content, "'$k'") !== false) continue;
        
        $v_esc = addcslashes($v, "'\\");
        $insert .= "    '$k' => '$v_esc',\n";
    }
    
    if ($insert !== "") {
        // Find the last ];
        $content = preg_replace('/];\s*$/', $insert . "];\n", $content);
        file_put_contents($file, $content);
        echo "Added " . count($keys[$lang]) . " keys to $lang.php\n";
    } else {
        echo "No new keys for $lang.php\n";
    }
}
