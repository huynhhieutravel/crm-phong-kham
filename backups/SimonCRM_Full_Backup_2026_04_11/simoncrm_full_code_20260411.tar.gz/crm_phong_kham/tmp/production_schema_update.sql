-- tmp/production_schema_update.sql
USE clinic_management;
SET FOREIGN_KEY_CHECKS=0;

-- 1. Update patients table
ALTER TABLE patients ADD COLUMN IF NOT EXISTS label VARCHAR(50) DEFAULT "Khách mới" AFTER zalo_number;

-- 2. Create/Update medical_sessions table
CREATE TABLE IF NOT EXISTS medical_sessions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT NOT NULL,
    doctor_id INT NULL, -- Allowed NULL for ON DELETE SET NULL
    appointment_id INT NULL,
    session_date DATE NOT NULL,
    assessment TEXT,
    treatment_plan TEXT,
    status ENUM('active', 'completed') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Fix doctor_id if it was NOT NULL
ALTER TABLE medical_sessions MODIFY COLUMN doctor_id INT NULL;

-- 3. Add FKs to medical_sessions if they don't exist
ALTER TABLE medical_sessions ADD CONSTRAINT fk_medical_sessions_patient FOREIGN KEY IF NOT EXISTS (patient_id) REFERENCES patients(id) ON DELETE CASCADE;
ALTER TABLE medical_sessions ADD CONSTRAINT fk_medical_sessions_doctor FOREIGN KEY IF NOT EXISTS (doctor_id) REFERENCES users(id) ON DELETE SET NULL;
ALTER TABLE medical_sessions ADD CONSTRAINT fk_medical_sessions_appointment FOREIGN KEY IF NOT EXISTS (appointment_id) REFERENCES appointments(id) ON DELETE SET NULL;


-- 4. Update medical_history table
-- Check if column exists is handled by ADD COLUMN IF NOT EXISTS in some MariaDB versions, 
-- but for standard MySQL we use ALTER TABLE ADD COLUMN ... if it fails it's fine.
-- Using a simpler approach here.
ALTER TABLE medical_history ADD COLUMN IF NOT EXISTS session_id INT NULL AFTER patient_id;
ALTER TABLE medical_history MODIFY COLUMN type VARCHAR(50) NOT NULL;
-- Use a unique name for history session fk
ALTER TABLE medical_history ADD CONSTRAINT fk_history_session FOREIGN KEY IF NOT EXISTS (session_id) REFERENCES medical_sessions(id) ON DELETE SET NULL;

-- 5. Update appointments table
ALTER TABLE appointments ADD COLUMN IF NOT EXISTS type VARCHAR(50) DEFAULT "consultation" AFTER doctor_id;

-- 6. Update roles
INSERT IGNORE INTO roles (name, display_name) VALUES ('cskh', 'Chăm sóc khách hàng');

SET FOREIGN_KEY_CHECKS=1;
