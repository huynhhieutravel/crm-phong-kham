<?php
require_once __DIR__ . '/../includes/db.php';
$db = getDB();
print_r($db->query("DESCRIBE patient_packages")->fetchAll(PDO::FETCH_ASSOC));
print_r($db->query("DESCRIBE transactions")->fetchAll(PDO::FETCH_ASSOC));
