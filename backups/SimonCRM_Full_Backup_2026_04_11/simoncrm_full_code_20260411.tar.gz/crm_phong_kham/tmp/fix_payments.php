<?php
require_once __DIR__ . '/../includes/db.php';
$db = getDB();

try {
    $db->beginTransaction();
    // 1. Fix old negative packages values
    $db->query("UPDATE patient_packages SET total_amount = ABS(total_amount), paid_amount = ABS(paid_amount) WHERE total_amount < 0 OR paid_amount < 0");
    
    // 2. Fix old negative transactions values where category is 'package'
    $db->query("UPDATE transactions SET amount = ABS(amount) WHERE amount < 0 AND category = 'package' AND type = 'income'");
    
    $db->commit();
    echo "DB DATA FIXED SUCCESSFULLY";
} catch (Exception $e) {
    $db->rollBack();
    echo "ERROR: " . $e->getMessage();
}
