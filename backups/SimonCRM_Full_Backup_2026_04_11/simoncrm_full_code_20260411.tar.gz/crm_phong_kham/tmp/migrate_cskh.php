<?php
/**
 * Migration: CSKH Module Tables
 * Creates cskh_rules, cskh_tasks, cskh_interaction_logs
 * Safe to run multiple times (CREATE TABLE IF NOT EXISTS + INSERT IGNORE)
 */
require_once __DIR__ . '/../includes/db.php';

$db = getDB();

echo "=== CSKH MODULE MIGRATION START ===\n";

// 1. Rules Table (No-Hardcode configuration)
$db->exec("
CREATE TABLE IF NOT EXISTS cskh_rules (
    id INT AUTO_INCREMENT PRIMARY KEY,
    rule_name VARCHAR(255) NOT NULL,
    trigger_event ENUM('appointment_upcoming','session_completed','package_low_sessions','reactivation') NOT NULL,
    offset_days INT NOT NULL DEFAULT 0 COMMENT 'Negative = before, Positive = after',
    default_color ENUM('red','yellow','green','gray') NOT NULL DEFAULT 'yellow',
    retry_max INT NOT NULL DEFAULT 3,
    retry_interval_days INT NOT NULL DEFAULT 1,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
");
echo "[OK] cskh_rules created\n";

// 2. Tasks Table (Anti-Duplicate with UNIQUE KEY)
$db->exec("
CREATE TABLE IF NOT EXISTS cskh_tasks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT NOT NULL,
    rule_id INT NOT NULL,
    reference_id INT DEFAULT NULL COMMENT 'appointment_id or session_id or patient_package_id',
    reference_type ENUM('appointment','session','package') DEFAULT NULL,
    due_date DATE NOT NULL,
    status ENUM('pending','in_progress','completed','canceled','overdue') NOT NULL DEFAULT 'pending',
    priority_color ENUM('red','yellow','green','gray') NOT NULL DEFAULT 'yellow',
    retry_count INT NOT NULL DEFAULT 0,
    assigned_to INT DEFAULT NULL,
    resolved_by INT DEFAULT NULL,
    resolved_at DATETIME DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    UNIQUE KEY uk_rule_reference (rule_id, reference_id, reference_type),
    KEY idx_status (status),
    KEY idx_due_date (due_date),
    KEY idx_patient (patient_id),
    KEY idx_color (priority_color),
    
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE,
    FOREIGN KEY (rule_id) REFERENCES cskh_rules(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
");
echo "[OK] cskh_tasks created\n";

// 3. Interaction Logs Table (Retry + Notes)
$db->exec("
CREATE TABLE IF NOT EXISTS cskh_interaction_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    task_id INT NOT NULL,
    patient_id INT NOT NULL,
    interaction_result ENUM('answered','busy','no_answer','wrong_number','voicemail','other') NOT NULL DEFAULT 'other',
    call_outcome ENUM('booked','thinking','refused','follow_up','info_only') DEFAULT NULL COMMENT 'What happened after the call',
    notes TEXT DEFAULT NULL,
    has_asked_review TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'Asked for Google review?',
    post_care_notes TEXT DEFAULT NULL COMMENT 'Nhắc nhở sau khám',
    created_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    KEY idx_task (task_id),
    KEY idx_patient (patient_id),
    
    FOREIGN KEY (task_id) REFERENCES cskh_tasks(id) ON DELETE CASCADE,
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
");
echo "[OK] cskh_interaction_logs created\n";

// 4. Seed Default Rules
$rules = [
    ['Nhắc lịch khám ngày mai (T-1)', 'appointment_upcoming', -1, 'red', 2, 0],
    ['Hỏi thăm sau điều trị (T+3)', 'session_completed', 3, 'yellow', 3, 1],
    ['Gọi lại sau 7 ngày chưa đặt lịch', 'session_completed', 7, 'red', 3, 2],
    ['Cảnh báo gói sắp hết (≤2 buổi)', 'package_low_sessions', 0, 'red', 2, 1],
    ['Đánh thức khách lâu chưa khám (30 ngày)', 'reactivation', 30, 'gray', 3, 7],
];

$stmt = $db->prepare("
    INSERT IGNORE INTO cskh_rules (rule_name, trigger_event, offset_days, default_color, retry_max, retry_interval_days)
    VALUES (?, ?, ?, ?, ?, ?)
");

foreach ($rules as $r) {
    $stmt->execute($r);
}
echo "[OK] Default rules seeded (" . count($rules) . " rules)\n";

echo "\n=== CSKH MODULE MIGRATION COMPLETE ===\n";
