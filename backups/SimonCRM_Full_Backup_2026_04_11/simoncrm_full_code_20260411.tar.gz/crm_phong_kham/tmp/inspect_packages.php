<?php
require_once __DIR__ . '/../includes/db.php';
$db = getDB();
$pkgs = $db->query("SELECT * FROM packages")->fetchAll(PDO::FETCH_ASSOC);
file_put_contents(__DIR__ . '/packages_dump.json', json_encode($pkgs, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));
echo "Done";
