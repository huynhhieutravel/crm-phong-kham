<?php
// tmp/seed_comprehensive.php
require_once __DIR__ . '/../includes/db.php';

$db = getDB();

$patients = [
    ['full_name' => 'Lê Thị Mai', 'phone' => '0912345671', 'email' => 'mai.le@gmail.com', 'address' => '123 Phố Huế, Hai Bà Trưng, Hà Nội', 'gender' => 'female', 'dob' => '1985-05-15', 'label' => 'Khách mới'],
    ['full_name' => 'Trần Văn Hoàng', 'phone' => '0987654321', 'email' => 'hoang.tran@yahoo.com', 'address' => '456 Lê Lợi, Quận 1, TP.HCM', 'gender' => 'male', 'dob' => '1978-10-20', 'label' => 'Cần chăm sóc'],
    ['full_name' => 'Nguyễn Thị Lan', 'phone' => '0901122334', 'email' => 'lan.nguyen@outlook.com', 'address' => '789 Trần Hưng Đạo, Đà Nẵng', 'gender' => 'female', 'dob' => '1992-02-28', 'label' => 'Đang điều trị'],
    ['full_name' => 'Phạm Minh Đức', 'phone' => '0933445566', 'email' => 'duc.pham@gmail.com', 'address' => '101 Lạch Tray, Hải Phòng', 'gender' => 'male', 'dob' => '1980-12-12', 'label' => 'Đang điều trị'],
    ['full_name' => 'Vũ Hoàng Nam', 'phone' => '0944556677', 'email' => 'nam.vu@gmail.com', 'address' => '202 Nguyễn Trãi, Cần Thơ', 'gender' => 'male', 'dob' => '1995-07-04', 'label' => 'Khách mới'],
    ['full_name' => 'Đặng Thu Thảo', 'phone' => '0355667788', 'email' => 'thao.dang@gmail.com', 'address' => '303 Hùng Thắng, Hạ Long, Quảng Ninh', 'gender' => 'female', 'dob' => '1988-09-09', 'label' => 'Vip'],
    ['full_name' => 'Bùi Thế Anh', 'phone' => '0366778899', 'email' => 'anh.bui@gmail.com', 'address' => '404 Đại lộ Bình Dương, Thủ Dầu Một', 'gender' => 'male', 'dob' => '1972-01-25', 'label' => 'Khách cũ'],
    ['full_name' => 'Đỗ Minh Trang', 'phone' => '0377889900', 'email' => 'trang.do@gmail.com', 'address' => '505 Biên Hòa, Đồng Nai', 'gender' => 'female', 'dob' => '2000-06-18', 'label' => 'Khách mới'],
    ['full_name' => 'Lương Gia Bảo', 'phone' => '0388990011', 'email' => 'bao.luong@gmail.com', 'address' => '606 Tân An, Long An', 'gender' => 'male', 'dob' => '2010-11-11', 'label' => 'Khách mới'],
    ['full_name' => 'Phan Thanh Tùng', 'phone' => '0399001122', 'email' => 'tung.phan@gmail.com', 'address' => '707 Mỹ Tho, Tiền Giang', 'gender' => 'male', 'dob' => '1965-03-30', 'label' => 'Đang điều trị'],
    ['full_name' => 'Ngô Kim Chi', 'phone' => '0811223344', 'email' => 'chi.ngo@gmail.com', 'address' => '808 Tây Ninh', 'gender' => 'female', 'dob' => '1998-12-05', 'label' => 'Khách mới'],
    ['full_name' => 'Trịnh Duy Kiên', 'phone' => '0822334455', 'email' => 'kien.trinh@gmail.com', 'address' => '909 Vũng Tàu', 'gender' => 'male', 'dob' => '1982-08-16', 'label' => 'Đang điều trị'],
];

$patient_ids = [];
foreach ($patients as $p) {
    $stmt = $db->prepare("INSERT INTO patients (full_name, phone, email, address, gender, birthday, label) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$p['full_name'], $p['phone'], $p['email'], $p['address'], $p['gender'], $p['dob'], $p['label']]);
    $patient_ids[$p['full_name']] = $db->lastInsertId();
}

$doctor_ids = [2, 3]; // From previous check
$statuses = ['scheduled', 'confirmed', 'arrived', 'completed', 'no_show'];
$types = ['consultation', 'treatment', 're_exam', 'adjustment'];

$appointments_data = [
    ['patient' => 'Lê Thị Mai', 'doctor' => 2, 'date' => date('Y-m-d 09:00:00'), 'status' => 'completed', 'type' => 'consultation'],
    ['patient' => 'Trần Văn Hoàng', 'doctor' => 3, 'date' => date('Y-m-d 10:30:00'), 'status' => 'completed', 'type' => 'treatment'],
    ['patient' => 'Nguyễn Thị Lan', 'doctor' => 2, 'date' => date('Y-m-d 14:00:00'), 'status' => 'arrived', 'type' => 'consultation'],
    ['patient' => 'Phạm Minh Đức', 'doctor' => 3, 'date' => date('Y-m-d 15:30:00', strtotime('+1 day')), 'status' => 'scheduled', 'type' => 'treatment'],
    ['patient' => 'Vũ Hoàng Nam', 'doctor' => 2, 'date' => date('Y-m-d 14:00:00', strtotime('+2 days')), 'status' => 'scheduled', 'type' => 'consultation'],
    ['patient' => 'Đặng Thu Thảo', 'doctor' => 3, 'date' => date('Y-m-d 09:00:00', strtotime('+3 days')), 'status' => 'scheduled', 'type' => 'treatment'],
    ['patient' => 'Bùi Thế Anh', 'doctor' => 2, 'date' => date('Y-m-d 11:00:00', strtotime('+4 days')), 'status' => 'scheduled', 'type' => 're_exam'],
    ['patient' => 'Đỗ Minh Trang', 'doctor' => 3, 'date' => date('Y-m-d 16:00:00', strtotime('+5 days')), 'status' => 'scheduled', 'type' => 'consultation'],
    ['patient' => 'Lương Gia Bảo', 'doctor' => 2, 'date' => date('Y-m-d 08:30:00', strtotime('+6 days')), 'status' => 'scheduled', 'type' => 'adjustment'],
    ['patient' => 'Phan Thanh Tùng', 'doctor' => 3, 'date' => date('Y-m-d 10:00:00', strtotime('+7 days')), 'status' => 'scheduled', 'type' => 're_exam'],
    ['patient' => 'Ngô Kim Chi', 'doctor' => 2, 'date' => date('Y-m-d 13:30:00', strtotime('+8 days')), 'status' => 'scheduled', 'type' => 'consultation'],
    ['patient' => 'Trịnh Duy Kiên', 'doctor' => 3, 'date' => date('Y-m-d 15:00:00', strtotime('+9 days')), 'status' => 'scheduled', 'type' => 'treatment'],
    ['patient' => 'Lê Thị Mai', 'doctor' => 2, 'date' => date('Y-m-d 09:00:00', strtotime('+14 days')), 'status' => 'scheduled', 'type' => 'treatment'],
    ['patient' => 'Trần Văn Hoàng', 'doctor' => 3, 'date' => date('Y-m-d 10:30:00', strtotime('+15 days')), 'status' => 'scheduled', 'type' => 're_exam'],
    ['patient' => 'Nguyễn Thị Lan', 'doctor' => 2, 'date' => date('Y-m-d 14:00:00', strtotime('-1 day')), 'status' => 'completed', 'type' => 'consultation'],
];

foreach ($appointments_data as $a) {
    $pid = $patient_ids[$a['patient']];
    $stmt = $db->prepare("INSERT INTO appointments (patient_id, doctor_id, appointment_date, status, type, branch_id) VALUES (?, ?, ?, ?, ?, 1)");
    $stmt->execute([$pid, $a['doctor'], $a['date'], $a['status'], $a['type']]);
    $appt_id = $db->lastInsertId();

    if ($a['status'] === 'completed' || $a['status'] === 'arrived') {
        // Create Medical Session
        $assessment = "<p>Bệnh nhân đau cấp vùng thắt lưng, lan xuống chân trái. VAS 7/10. Hạn chế vận động gập lưng.</p>";
        $plan = "<ul><li>Chiropractic Adjustment (L4-L5, Pelvis)</li><li>Physical Therapy (Laser, Ultrasound)</li><li>Tái khám sau 2 ngày.</li></ul>";
        
        $stmt_s = $db->prepare("INSERT INTO medical_sessions (patient_id, appointment_id, doctor_id, session_date, assessment, treatment_plan, status) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt_s->execute([$pid, $appt_id, $a['doctor'], date('Y-m-d', strtotime($a['date'])), $assessment, $plan, 'completed']);
        $session_id = $db->lastInsertId();

        // Add Medical Records for specific test patients
        if ($a['patient'] === 'Lê Thị Mai') {
            // Chiro History
            $history_data_h = json_encode([
                'chief_complaint' => 'Đau thắt lưng lan chân trái',
                'pain_points' => ['Lower Back', 'Left Leg'],
                'duration' => '3 weeks',
                'onset' => 'Sudden after lifting heavy object',
                'ros' => ['numbness' => 'yes', 'weakness' => 'no'],
                'past_medical' => ['hypertension' => 'no', 'diabetes' => 'no']
            ]);
            $stmt_m = $db->prepare("INSERT INTO medical_history (session_id, patient_id, type, history_data) VALUES (?, ?, ?, ?)");
            $stmt_m->execute([$session_id, $pid, 'chiro_history', $history_data_h]);

            // Chiro Exam with Markers integrated
            $exam_data = json_encode([
                'markers' => [
                    ['type' => 'marker', 'x' => 150, 'y' => 300, 'intensity' => 8, 'label' => 'M1'],
                    ['type' => 'marker', 'x' => 160, 'y' => 450, 'intensity' => 5, 'label' => 'M2']
                ],
                'spine_nodes' => ['L4' => ['subluxation' => 'P-L'], 'L5' => ['subluxation' => 'P-R']]
            ]);
            $stmt_e = $db->prepare("INSERT INTO medical_history (session_id, patient_id, type, history_data) VALUES (?, ?, ?, ?)");
            $stmt_e->execute([$session_id, $pid, 'chiro_exam', $exam_data]);
            
            // SOAP
            $soap_data = json_encode([
                'subjective' => 'Bớt đau hơn buổi sáng',
                'objective' => 'Cơ thắt lưng còn co cứng',
                'assessment' => 'Thoát vị đĩa đệm L4-L5',
                'plan' => 'Tiếp tục lộ trình nắn chỉnh'
            ]);
            $stmt_soap = $db->prepare("INSERT INTO medical_history (session_id, patient_id, type, history_data) VALUES (?, ?, ?, ?)");
            $stmt_soap->execute([$session_id, $pid, 'soap', $soap_data]);
        }

        if ($a['patient'] === 'Nguyễn Thị Lan') {
            // TCM (Dong Y)
            $tcm_data = json_encode([
                'vong_chan' => 'Thần còn, sắc mặt hơi nhợt, lưỡi nhạt rêu trắng mỏng',
                'van_chan' => 'Tiếng nói nhỏ, hơi thở ngắn',
                'van_chan_hỏi' => 'Ngủ kém, hay mơ, ăn uống không ngon miệng',
                'thiet_chan' => 'Mạch trầm tế',
                'bat_cuong' => 'Lý, Hư, Hàn',
                'chan_doan' => 'Tâm tỳ lưỡng hư'
            ]);
            $stmt_tcm = $db->prepare("INSERT INTO medical_history (session_id, patient_id, type, history_data) VALUES (?, ?, ?, ?)");
            $stmt_tcm->execute([$session_id, $pid, 'dong_y', $tcm_data]);
        }
    }
}

echo "Seeded 12 patients, 15 appointments, and clinical records successfully!\n";
