#!/bin/bash
# tmp/deploy_vps.sh

SOURCE_DIR="/Volumes/T7 Loki SS/WORK Hiếu/quan-ly-phong-kham/"
REMOTE_HOST="64.176.85.168"
REMOTE_USER="root"
REMOTE_DIR="/var/www/crm.simoncenter.vn/"

# Export password for sshpass -e (avoids shell escaping issues with special chars)
export SSHPASS='#Aa2,zdf87a@Q{3q'

echo "Starting file synchronization..."

sshpass -e rsync -avz --delete \
    --exclude='.git/' \
    --exclude='.gitignore' \
    --exclude='config/database.php' \
    --exclude='uploads/*' \
    --exclude='.gemini/' \
    --exclude='.agents/' \
    --exclude='.agent/' \
    --exclude='_agents/' \
    --exclude='_agent/' \
    --exclude='brain/' \
    --exclude='tmp/' \
    --exclude='database.sqlite' \
    --exclude='modules/database.db' \
    -e "ssh -o StrictHostKeyChecking=no" \
    "$SOURCE_DIR" "$REMOTE_USER@$REMOTE_HOST:$REMOTE_DIR"

echo "File synchronization complete."

# Update Database on VPS using migrate_vps.php
echo "Updating Database on VPS..."
sshpass -e ssh -o StrictHostKeyChecking=no "$REMOTE_USER@$REMOTE_HOST" \
    "php $REMOTE_DIR/migrate_vps.php" || echo "Warning: DB update failed."

# Fix permissions on VPS
echo "Setting permissions on VPS..."
sshpass -e ssh -o StrictHostKeyChecking=no "$REMOTE_USER@$REMOTE_HOST" \
    "chmod -R 755 $REMOTE_DIR && chown -R www-data:www-data $REMOTE_DIR" || echo "Warning: Permission set failed."

echo "Deployment finished successfully."
