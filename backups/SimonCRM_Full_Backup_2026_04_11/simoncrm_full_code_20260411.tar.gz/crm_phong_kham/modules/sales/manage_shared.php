<?php
// modules/sales/manage_shared.php
require_once '../../includes/db.php';
require_once '../../includes/functions.php';
require_once '../../includes/auth_middleware.php';
require_permission('manage_sales');

$db = getDB();
$pp_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Handle add shared user
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'add_user') {
        $stmt = $db->prepare("INSERT IGNORE INTO package_shared_users (patient_package_id, patient_id, added_by) VALUES (?, ?, ?)");
        $stmt->execute([$pp_id, $_POST['patient_id'], $_SESSION['user_id']]);
        set_flash('Đã thêm người dùng chung thành công!');
    } elseif ($_POST['action'] === 'remove_user') {
        $stmt = $db->prepare("DELETE FROM package_shared_users WHERE id = ? AND patient_package_id = ?");
        $stmt->execute([$_POST['share_id'], $pp_id]);
        set_flash('Đã xóa người dùng chung.');
    }
    redirect("manage_shared.php?id=$pp_id");
}

// Get package info
$stmt = $db->prepare("
    SELECT pp.*, pkg.name as package_name, pkg.total_sessions, pkg.total_price,
           pt.full_name as owner_name, pt.phone as owner_phone
    FROM patient_packages pp
    JOIN packages pkg ON pp.package_id = pkg.id
    JOIN patients pt ON pp.patient_id = pt.id
    WHERE pp.id = ?
");
$stmt->execute([$pp_id]);
$package = $stmt->fetch();

if (!$package) {
    set_flash('Không tìm thấy gói.', 'error');
    redirect('index.php');
}

// Get shared users
$stmt = $db->prepare("
    SELECT psu.*, p.full_name, p.phone, u.full_name as added_by_name
    FROM package_shared_users psu
    JOIN patients p ON psu.patient_id = p.id
    LEFT JOIN users u ON psu.added_by = u.id
    WHERE psu.patient_package_id = ?
    ORDER BY psu.added_at DESC
");
$stmt->execute([$pp_id]);
$shared_users = $stmt->fetchAll();

// Get usage history
$stmt = $db->prepare("
    SELECT pul.*, p.full_name as used_by_name, t.treatment_date, t.session_data,
           u.full_name as technician_name, pay.method as payment_method, pay.amount as payment_amount
    FROM package_usage_logs pul
    JOIN patients p ON pul.patient_id = p.id
    JOIN treatments t ON pul.treatment_id = t.id
    LEFT JOIN users u ON t.technician_id = u.id
    LEFT JOIN payments pay ON pay.treatment_id = t.id AND pay.patient_package_id = pul.patient_package_id
    WHERE pul.patient_package_id = ?
    ORDER BY pul.used_at DESC
");
$stmt->execute([$pp_id]);
$usage_logs = $stmt->fetchAll();

// Get all patients for the add dropdown
$patients = $db->query("SELECT id, full_name, phone FROM patients ORDER BY full_name ASC")->fetchAll();

$page_title = 'Quản Lý Gói: ' . $package['package_name'];
$current_page = 'sales';
require_once '../../templates/header.php';

$per_session = $package['total_sessions'] > 0 ? ($package['total_price'] / $package['total_sessions']) : 0;
$sessions_used = $package['total_sessions'] - $package['sessions_remaining'];
?>

<style>
.pkg-hero {
    background: linear-gradient(135deg, #6366f1, #8b5cf6);
    padding: 2rem; border-radius: 20px; color: white; margin-bottom: 2rem;
    box-shadow: 0 10px 30px rgba(99,102,241,0.3);
}
.pkg-hero h1 { font-size: 1.5rem; font-weight: 800; margin: 0 0 1rem 0; }
.pkg-stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 1rem; }
.pkg-stat { text-align: center; }
.pkg-stat .val { font-size: 1.8rem; font-weight: 800; }
.pkg-stat .lbl { font-size: 0.75rem; opacity: 0.8; text-transform: uppercase; font-weight: 700; letter-spacing: 0.5px; }

.section-card { background: white; border-radius: 20px; padding: 2rem; margin-bottom: 1.5rem; box-shadow: 0 4px 20px rgba(0,0,0,0.03); }
.section-title { font-size: 1.15rem; font-weight: 800; color: #1e293b; margin-bottom: 1.5rem; display: flex; align-items: center; gap: 0.6rem; }
.section-title i { color: var(--primary); }

.shared-badge {
    display: inline-flex; align-items: center; gap: 0.5rem;
    background: #f1f5f9; padding: 0.5rem 1rem; border-radius: 10px; margin: 0.3rem;
    font-weight: 600; font-size: 0.9rem; color: #334155;
}
.shared-badge .remove-btn {
    color: #ef4444; cursor: pointer; font-size: 0.8rem; margin-left: 0.5rem;
    background: #fee2e2; width: 22px; height: 22px; border-radius: 50%; display: flex; align-items: center; justify-content: center;
    border: none; transition: all 0.2s;
}
.shared-badge .remove-btn:hover { background: #fca5a5; }

@media (max-width: 768px) { .pkg-stats { grid-template-columns: repeat(2, 1fr); } }
</style>

<div style="max-width: 900px; margin: 0 auto;">
    <a href="index.php" style="display: inline-flex; align-items: center; gap: 0.5rem; color: var(--primary); font-weight: 700; font-size: 0.9rem; text-decoration: none; margin-bottom: 1rem;">
        <i class="fas fa-arrow-left"></i> Quay lại danh sách gói
    </a>

    <!-- Package Hero -->
    <div class="pkg-hero">
        <h1><i class="fas fa-box-open"></i> <?php echo e($package['package_name']); ?></h1>
        <div style="margin-bottom: 1rem; opacity: 0.9;">
            <i class="fas fa-user"></i> Chủ gói: <strong><?php echo e($package['owner_name']); ?></strong>
            (<?php echo e($package['owner_phone']); ?>)
            · Mua ngày: <?php echo date('d/m/Y', strtotime($package['purchase_date'])); ?>
        </div>
        <div class="pkg-stats">
            <div class="pkg-stat">
                <div class="val"><?php echo $package['sessions_remaining']; ?></div>
                <div class="lbl">Buổi còn lại</div>
            </div>
            <div class="pkg-stat">
                <div class="val"><?php echo $sessions_used; ?></div>
                <div class="lbl">Đã sử dụng</div>
            </div>
            <div class="pkg-stat">
                <div class="val"><?php echo format_money($per_session); ?></div>
                <div class="lbl">Giá / buổi</div>
            </div>
            <div class="pkg-stat">
                <div class="val" style="color: <?php echo $package['status'] === 'active' ? '#4ade80' : '#fbbf24'; ?>;">
                    <?php echo strtoupper($package['status']); ?>
                </div>
                <div class="lbl">Trạng thái</div>
            </div>
        </div>
    </div>

    <!-- Shared Users Management -->
    <div class="section-card">
        <div class="section-title"><i class="fas fa-users"></i> Người được phép sử dụng gói</div>
        
        <!-- Add user form -->
        <form method="POST" style="display: flex; gap: 0.75rem; margin-bottom: 1.5rem; flex-wrap: wrap;">
            <input type="hidden" name="action" value="add_user">
            <select name="patient_id" class="form-input" required style="flex: 1; min-width: 250px;">
                <option value="">-- Chọn bệnh nhân --</option>
                <?php foreach ($patients as $p): ?>
                    <?php if ($p['id'] != $package['patient_id']): // Exclude owner ?>
                        <option value="<?php echo $p['id']; ?>"><?php echo e($p['full_name']); ?> (<?php echo e($p['phone']); ?>)</option>
                    <?php endif; ?>
                <?php endforeach; ?>
            </select>
            <button type="submit" class="btn btn-primary" style="border-radius: 12px;">
                <i class="fas fa-plus"></i> Thêm người dùng
            </button>
        </form>

        <!-- List of shared users -->
        <div style="display: flex; flex-wrap: wrap; gap: 0.5rem;">
            <?php if (empty($shared_users)): ?>
                <div style="color: #94a3b8; font-style: italic;">Chưa chia sẻ cho ai. Thêm người bên trên để cho phép họ sử dụng gói này.</div>
            <?php endif; ?>
            <?php foreach ($shared_users as $su): ?>
                <div class="shared-badge">
                    <i class="fas fa-user-check" style="color: #10b981;"></i>
                    <?php echo e($su['full_name']); ?>
                    <span style="font-size: 0.75rem; color: #94a3b8;">(<?php echo e($su['phone']); ?>)</span>
                    <form method="POST" style="display: inline; margin: 0;">
                        <input type="hidden" name="action" value="remove_user">
                        <input type="hidden" name="share_id" value="<?php echo $su['id']; ?>">
                        <button type="submit" class="remove-btn" title="Xóa" onclick="return confirm('Xóa quyền sử dụng gói?');"><i class="fas fa-times"></i></button>
                    </form>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Usage History -->
    <div class="section-card">
        <div class="section-title"><i class="fas fa-history"></i> Lịch sử sử dụng gói (<?php echo count($usage_logs); ?> lượt)</div>
        
        <?php if (empty($usage_logs)): ?>
            <div style="text-align: center; padding: 2rem; color: #94a3b8;">
                <i class="fas fa-clipboard-list" style="font-size: 2rem; margin-bottom: 0.5rem;"></i>
                <div>Gói chưa được sử dụng lần nào.</div>
            </div>
        <?php else: ?>
            <table class="table" style="width: 100%;">
                <thead>
                    <tr style="text-align: left; border-bottom: 2px solid #e2e8f0;">
                        <th style="padding: 0.75rem;">Thời gian</th>
                        <th style="padding: 0.75rem;">Người sử dụng</th>
                        <th style="padding: 0.75rem;">KTV phụ trách</th>
                        <th style="padding: 0.75rem;">Giá trị</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($usage_logs as $log): ?>
                        <tr style="border-bottom: 1px solid #f1f5f9;">
                            <td style="padding: 0.75rem;">
                                <div style="font-weight: 700; color: #1e293b;"><?php echo date('H:i', strtotime($log['used_at'])); ?></div>
                                <div style="font-size: 0.8rem; color: #64748b;"><?php echo date('d/m/Y', strtotime($log['used_at'])); ?></div>
                            </td>
                            <td style="padding: 0.75rem;">
                                <strong><?php echo e($log['used_by_name']); ?></strong>
                                <?php if ($log['patient_id'] != $package['patient_id']): ?>
                                    <span style="font-size: 0.7rem; background: #fef3c7; color: #92400e; padding: 0.1rem 0.4rem; border-radius: 4px; margin-left: 0.3rem;">Dùng chung</span>
                                <?php endif; ?>
                            </td>
                            <td style="padding: 0.75rem;"><?php echo e($log['technician_name'] ?: '-'); ?></td>
                            <td style="padding: 0.75rem; font-weight: 700; color: var(--primary);"><?php echo format_money($per_session); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>

<?php require_once '../../templates/footer.php'; ?>
