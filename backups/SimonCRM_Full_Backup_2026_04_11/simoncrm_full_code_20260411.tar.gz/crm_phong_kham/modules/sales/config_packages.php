<?php
// modules/sales/config_packages.php
require_once '../../includes/db.php';
require_once '../../includes/functions.php';
require_once '../../includes/auth_middleware.php';
require_permission('manage_sales');
$page_title = 'Cấu hình Gói dịch vụ';
$current_page = 'sales';

$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!empty($_POST['package_id'])) {
        $stmt = $db->prepare("UPDATE packages SET name = ?, total_sessions = ?, total_price = ? WHERE id = ?");
        $stmt->execute([
            $_POST['name'],
            $_POST['total_sessions'],
            $_POST['total_price'],
            $_POST['package_id']
        ]);
        set_flash('Cập nhật gói thành công!');
    } else {
        $stmt = $db->prepare("INSERT INTO packages (name, total_sessions, total_price) VALUES (?, ?, ?)");
        $stmt->execute([
            $_POST['name'],
            $_POST['total_sessions'],
            $_POST['total_price']
        ]);
        set_flash('Thêm loại gói thành công!');
    }
    header('Location: config_packages.php');
    exit;
}

$edit_package = null;
if (isset($_GET['edit_id'])) {
    $stmt = $db->prepare("SELECT * FROM packages WHERE id = ?");
    $stmt->execute([$_GET['edit_id']]);
    $edit_package = $stmt->fetch();
}

require_once '../../templates/header.php';

$packages = $db->query("SELECT * FROM packages ORDER BY id DESC")->fetchAll();
?>

<div style="display: grid; grid-template-columns: 1fr 2fr; gap: 1.5rem;">
    <div class="card">
        <h3 style="margin-bottom: 1.5rem;"><?php echo $edit_package ? 'Sửa thông tin gói' : 'Thêm loại gói mới'; ?></h3>
        <form method="POST" action="config_packages.php">
            <?php if ($edit_package): ?>
                <input type="hidden" name="package_id" value="<?php echo $edit_package['id']; ?>">
            <?php endif; ?>
            
            <div class="form-group">
                <label class="form-label">Tên gói</label>
                <input type="text" name="name" class="form-input" required placeholder="Gói Chiropractic 10 buổi" value="<?php echo $edit_package ? e($edit_package['name']) : ''; ?>">
            </div>
            <div class="form-group">
                <label class="form-label">Số buổi</label>
                <input type="number" name="total_sessions" class="form-input" required placeholder="10" value="<?php echo $edit_package ? $edit_package['total_sessions'] : ''; ?>">
            </div>
            <div class="form-group">
                <label class="form-label">Giá trọn gói</label>
                <input type="number" name="total_price" class="form-input" required placeholder="5000000" value="<?php echo $edit_package ? $edit_package['total_price'] : ''; ?>">
            </div>
            
            <button type="submit" class="btn btn-primary" style="width: 100%; margin-top: 1rem;">
                <i class="fas <?php echo $edit_package ? 'fa-save' : 'fa-plus'; ?>"></i> <?php echo $edit_package ? 'Cập nhật gói' : 'Lưu loại gói'; ?>
            </button>
            
            <?php if ($edit_package): ?>
                <a href="config_packages.php" class="btn" style="width: 100%; margin-top: 0.5rem; text-align: center; display: block; box-sizing: border-box; text-decoration: none; background: #f1f5f9; color: #475569;">
                    Hủy chỉnh sửa
                </a>
            <?php endif; ?>
        </form>
    </div>

    <div class="card">
        <h3 style="margin-bottom: 1.5rem;">Danh sách loại gói hiện có</h3>
        <table class="table" style="width: 100%;">
            <thead>
                <tr style="text-align: left; border-bottom: 1px solid var(--border-color);">
                    <th style="padding: 0.75rem;">Tên gói</th>
                    <th style="padding: 0.75rem;">Số buổi</th>
                    <th style="padding: 0.75rem;">Đơn giá</th>
                    <th style="padding: 0.75rem; width: 80px; text-align: right;">Hành động</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($packages as $pkg): ?>
                    <tr style="border-bottom: 1px solid #f1f5f9; <?php echo ($edit_package && $edit_package['id'] == $pkg['id']) ? 'background: #f8fafc;' : ''; ?>">
                        <td style="padding: 0.75rem;"><strong><?php echo e($pkg['name']); ?></strong></td>
                        <td style="padding: 0.75rem;"><?php echo $pkg['total_sessions']; ?></td>
                        <td style="padding: 0.75rem;"><?php echo format_money($pkg['total_price']); ?></td>
                        <td style="padding: 0.75rem; text-align: right;">
                            <a href="config_packages.php?edit_id=<?php echo $pkg['id']; ?>" class="btn btn-sm" style="background: <?php echo ($edit_package && $edit_package['id'] == $pkg['id']) ? '#c7d2fe; color: #4338ca' : '#e0e7ff; color: #4f46e5'; ?>; padding: 0.35rem 0.6rem; font-size: 0.75rem;">
                                <i class="fas fa-edit"></i> <?php echo ($edit_package && $edit_package['id'] == $pkg['id']) ? 'Đang sửa' : 'Sửa'; ?>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once '../../templates/footer.php'; ?>
