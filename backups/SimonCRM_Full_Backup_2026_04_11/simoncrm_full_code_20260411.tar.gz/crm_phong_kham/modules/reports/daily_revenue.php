<?php
// modules/reports/daily_revenue.php
require_once '../../includes/db.php';
require_once '../../includes/functions.php';
require_once '../../includes/auth_middleware.php';
require_permission('view_reports');

$page_title = 'Báo Cáo Thực Thu';
$current_page = 'reports';
require_once '../../templates/header.php';

$db = getDB();

// Date filter
$report_date = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');
$period = isset($_GET['period']) ? $_GET['period'] : 'today';

if ($period === 'today') {
    $start = date('Y-m-d') . ' 00:00:00';
    $end = date('Y-m-d') . ' 23:59:59';
    $label = 'Hôm nay (' . date('d/m/Y') . ')';
} elseif ($period === 'custom' && $report_date) {
    $start = $report_date . ' 00:00:00';
    $end = $report_date . ' 23:59:59';
    $label = 'Ngày ' . date('d/m/Y', strtotime($report_date));
} elseif ($period === 'week') {
    $start = date('Y-m-d', strtotime('monday this week')) . ' 00:00:00';
    $end = date('Y-m-d', strtotime('sunday this week')) . ' 23:59:59';
    $label = 'Tuần này';
} elseif ($period === 'month') {
    $start = date('Y-m-01') . ' 00:00:00';
    $end = date('Y-m-t') . ' 23:59:59';
    $label = 'Tháng ' . date('m/Y');
} else {
    $start = date('Y-m-d') . ' 00:00:00';
    $end = date('Y-m-d') . ' 23:59:59';
    $label = 'Hôm nay';
}

$params = [$start, $end];

// 1. Revenue by method
$stmt = $db->prepare("
    SELECT method, COUNT(*) as count, SUM(amount) as total
    FROM payments
    WHERE created_at BETWEEN ? AND ?
    GROUP BY method
");
$stmt->execute($params);
$revenue_by_method = $stmt->fetchAll(PDO::FETCH_ASSOC);

$method_labels = [
    'cash' => ['label' => 'Tiền mặt', 'icon' => '💵', 'color' => '#10b981'],
    'transfer' => ['label' => 'Chuyển khoản', 'icon' => '🏦', 'color' => '#3b82f6'],
    'package' => ['label' => 'Gói dịch vụ', 'icon' => '📦', 'color' => '#8b5cf6'],
    'debt' => ['label' => 'Nợ phát sinh', 'icon' => '📝', 'color' => '#ef4444'],
];

$total_cash = 0; $total_transfer = 0; $total_package = 0; $total_debt = 0;
foreach ($revenue_by_method as $r) {
    if ($r['method'] === 'cash') $total_cash = $r['total'];
    if ($r['method'] === 'transfer') $total_transfer = $r['total'];
    if ($r['method'] === 'package') $total_package = $r['total'];
    if ($r['method'] === 'debt') $total_debt = $r['total'];
}
$total_revenue = $total_cash + $total_transfer + $total_package;

// 2. Package payment details
$stmt = $db->prepare("
    SELECT pay.*, p.full_name as patient_name, pkg_name.name as package_name,
           owner.full_name as owner_name
    FROM payments pay
    JOIN patients p ON pay.patient_id = p.id
    LEFT JOIN patient_packages pp ON pay.patient_package_id = pp.id
    LEFT JOIN packages pkg_name ON pp.package_id = pkg_name.id
    LEFT JOIN patients owner ON pay.payer_patient_id = owner.id
    WHERE pay.method = 'package' AND pay.created_at BETWEEN ? AND ?
    ORDER BY pay.created_at DESC
");
$stmt->execute($params);
$package_details = $stmt->fetchAll();

// 3. Staff productivity
$stmt = $db->prepare("
    SELECT u.full_name, u.id as user_id,
           COUNT(t.id) as total_cases,
           SUM(CASE WHEN pay.method IN ('cash','transfer') THEN pay.amount ELSE 0 END) as cash_revenue,
           SUM(CASE WHEN pay.method = 'package' THEN pay.amount ELSE 0 END) as package_value,
           SUM(CASE WHEN pay.method = 'debt' THEN pay.amount ELSE 0 END) as debt_amount
    FROM treatments t
    JOIN users u ON t.technician_id = u.id
    LEFT JOIN payments pay ON t.id = pay.treatment_id
    WHERE t.treatment_date BETWEEN ? AND ?
    GROUP BY u.id
    ORDER BY total_cases DESC
");
$stmt->execute($params);
$staff_data = $stmt->fetchAll();

// 4. All transactions list
$stmt = $db->prepare("
    SELECT pay.*, p.full_name as patient_name, t.treatment_date,
           u.full_name as created_by_name
    FROM payments pay
    JOIN patients p ON pay.patient_id = p.id
    LEFT JOIN treatments t ON pay.treatment_id = t.id
    LEFT JOIN users u ON pay.created_by = u.id
    WHERE pay.created_at BETWEEN ? AND ?
    ORDER BY pay.created_at DESC
");
$stmt->execute($params);
$all_payments = $stmt->fetchAll();
?>

<style>
.rev-outer { max-width: 1400px; width: 100%; }
.rev-filter {
    display: flex; align-items: center; gap: 1rem; flex-wrap: wrap;
    margin-bottom: 2rem; padding: 1.5rem; background: white; border-radius: 18px; box-shadow: 0 4px 20px rgba(0,0,0,0.03);
}
.rev-toggle { display: flex; background: #f1f5f9; padding: 5px; border-radius: 14px; gap: 4px; }
.rev-toggle a {
    padding: 0.6rem 1.2rem; border-radius: 10px; font-size: 0.85rem; font-weight: 600; color: #64748b;
    text-decoration: none; transition: all 0.2s; border: none; background: transparent;
}
.rev-toggle a:hover:not(.active) { background: rgba(255,255,255,0.6); color: var(--primary); }
.rev-toggle a.active { background: white; color: var(--primary); box-shadow: 0 4px 12px rgba(0,0,0,0.08); }

.rev-stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 1.5rem; margin-bottom: 2rem; }
@media (max-width: 1024px) { .rev-stats { grid-template-columns: repeat(2, 1fr); } }
@media (max-width: 600px) { .rev-stats { grid-template-columns: 1fr; } }

.rev-card {
    padding: 2rem; border-radius: 20px; color: white; position: relative; overflow: hidden;
    box-shadow: 0 10px 25px -5px rgba(0,0,0,0.1); transition: all 0.3s;
}
.rev-card:hover { transform: translateY(-4px); }
.rev-card .rev-icon { position: absolute; right: -5px; bottom: -5px; font-size: 4rem; opacity: 0.15; }
.rev-card .rev-label { font-size: 0.8rem; font-weight: 700; text-transform: uppercase; opacity: 0.85; letter-spacing: 0.5px; }
.rev-card .rev-val { font-size: 2rem; font-weight: 800; margin-top: 0.5rem; }
.rev-card .rev-sub { font-size: 0.85rem; opacity: 0.8; margin-top: 0.3rem; }

.section-card { background: white; border-radius: 20px; padding: 2rem; margin-bottom: 1.5rem; box-shadow: 0 4px 20px rgba(0,0,0,0.03); }
.section-title { font-size: 1.15rem; font-weight: 800; color: #1e293b; margin-bottom: 1.5rem; display: flex; align-items: center; gap: 0.6rem; }
.section-title i { color: var(--primary); }
</style>

<div class="content-body">
    <div class="rev-outer">
        <div class="breadcrumb mb-2" style="font-size: 0.75rem; font-weight: 700; letter-spacing: 1px; color: #94a3b8;">
            CRM / BÁO CÁO / THỰC THU
        </div>
        <h1 style="font-size: 2rem; font-weight: 800; color: #0f172a; margin-bottom: 1.5rem;">
            💰 Báo Cáo Thực Thu — <?php echo $label; ?>
        </h1>

        <!-- Filter -->
        <div class="rev-filter">
            <div class="rev-toggle">
                <a href="?period=today" class="<?php echo $period === 'today' ? 'active' : ''; ?>">Hôm nay</a>
                <a href="?period=week" class="<?php echo $period === 'week' ? 'active' : ''; ?>">Tuần này</a>
                <a href="?period=month" class="<?php echo $period === 'month' ? 'active' : ''; ?>">Tháng này</a>
            </div>
            <form method="GET" style="display: flex; align-items: center; gap: 0.5rem;">
                <input type="hidden" name="period" value="custom">
                <input type="date" name="date" value="<?php echo $report_date; ?>" class="form-input" style="border-radius: 10px; padding: 0.5rem 0.8rem; font-weight: 600;">
                <button type="submit" class="btn btn-primary" style="border-radius: 10px; padding: 0.5rem 1rem;">Xem</button>
            </form>
        </div>

        <!-- Revenue KPIs -->
        <div class="rev-stats">
            <div class="rev-card" style="background: linear-gradient(135deg, #10b981, #34d399);">
                <div class="rev-icon">💵</div>
                <div class="rev-label">Tiền Mặt</div>
                <div class="rev-val"><?php echo format_money($total_cash); ?></div>
            </div>
            <div class="rev-card" style="background: linear-gradient(135deg, #3b82f6, #60a5fa);">
                <div class="rev-icon">🏦</div>
                <div class="rev-label">Chuyển Khoản</div>
                <div class="rev-val"><?php echo format_money($total_transfer); ?></div>
            </div>
            <div class="rev-card" style="background: linear-gradient(135deg, #8b5cf6, #a78bfa);">
                <div class="rev-icon">📦</div>
                <div class="rev-label">Gói Dịch Vụ (quy đổi)</div>
                <div class="rev-val"><?php echo format_money($total_package); ?></div>
            </div>
            <div class="rev-card" style="background: linear-gradient(135deg, #ef4444, #f87171);">
                <div class="rev-icon">📝</div>
                <div class="rev-label">Nợ Phát Sinh</div>
                <div class="rev-val"><?php echo format_money($total_debt); ?></div>
            </div>
        </div>

        <!-- Total Summary -->
        <div class="section-card" style="background: linear-gradient(135deg, #0f172a, #1e293b); color: white; text-align: center; padding: 2.5rem;">
            <div style="font-size: 0.9rem; font-weight: 700; text-transform: uppercase; opacity: 0.7; letter-spacing: 1px;">TỔNG THỰC THU (Mặt + CK + Gói)</div>
            <div style="font-size: 3rem; font-weight: 800; margin-top: 0.5rem;"><?php echo format_money($total_revenue); ?></div>
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem;">
            <!-- Package Payment Details -->
            <div class="section-card">
                <div class="section-title"><i class="fas fa-box-open"></i> Chi Tiết Thanh Toán Bằng Gói</div>
                <?php if (empty($package_details)): ?>
                    <div style="text-align: center; padding: 2rem; color: #94a3b8;">Không có giao dịch gói trong kỳ.</div>
                <?php else: ?>
                    <table class="table" style="width: 100%;">
                        <thead>
                            <tr style="border-bottom: 2px solid #e2e8f0; text-align: left;">
                                <th style="padding: 0.6rem;">Bệnh nhân</th>
                                <th style="padding: 0.6rem;">Gói</th>
                                <th style="padding: 0.6rem;">Chủ gói</th>
                                <th style="padding: 0.6rem;">Giá trị</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($package_details as $pd): ?>
                                <tr style="border-bottom: 1px solid #f1f5f9;">
                                    <td style="padding: 0.6rem; font-weight: 600;"><?php echo e($pd['patient_name']); ?></td>
                                    <td style="padding: 0.6rem; font-size: 0.85rem;"><?php echo e($pd['package_name'] ?: '-'); ?></td>
                                    <td style="padding: 0.6rem;">
                                        <?php if ($pd['owner_name'] && $pd['owner_name'] !== $pd['patient_name']): ?>
                                            <span style="font-size: 0.75rem; background: #fef3c7; color: #92400e; padding: 0.15rem 0.4rem; border-radius: 4px;">
                                                <?php echo e($pd['owner_name']); ?>
                                            </span>
                                        <?php else: ?>
                                            <span style="color: #94a3b8;">Tự sở hữu</span>
                                        <?php endif; ?>
                                    </td>
                                    <td style="padding: 0.6rem; font-weight: 700; color: var(--primary);"><?php echo format_money($pd['amount']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>

            <!-- Staff Productivity -->
            <div class="section-card">
                <div class="section-title"><i class="fas fa-user-tie"></i> Năng Suất Nhân Viên</div>
                <?php if (empty($staff_data)): ?>
                    <div style="text-align: center; padding: 2rem; color: #94a3b8;">Không có dữ liệu trong kỳ.</div>
                <?php else: ?>
                    <table class="table" style="width: 100%;">
                        <thead>
                            <tr style="border-bottom: 2px solid #e2e8f0; text-align: left;">
                                <th style="padding: 0.6rem;">KTV / Bác sĩ</th>
                                <th style="padding: 0.6rem; text-align: center;">Số ca</th>
                                <th style="padding: 0.6rem; text-align: right;">Tiền thu</th>
                                <th style="padding: 0.6rem; text-align: right;">Gói (quy đổi)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($staff_data as $s): ?>
                                <tr style="border-bottom: 1px solid #f1f5f9;">
                                    <td style="padding: 0.6rem; font-weight: 700;"><?php echo e($s['full_name']); ?></td>
                                    <td style="padding: 0.6rem; text-align: center;">
                                        <span style="font-size: 1.1rem; font-weight: 800; color: #1e293b;"><?php echo $s['total_cases']; ?></span>
                                        <span style="font-size: 0.8rem; color: #64748b;"> ca</span>
                                    </td>
                                    <td style="padding: 0.6rem; text-align: right; font-weight: 700; color: #10b981;">
                                        <?php echo format_money($s['cash_revenue']); ?>
                                    </td>
                                    <td style="padding: 0.6rem; text-align: right; font-weight: 700; color: #8b5cf6;">
                                        <?php echo format_money($s['package_value']); ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>

        <!-- All Transactions -->
        <div class="section-card">
            <div class="section-title"><i class="fas fa-receipt"></i> Tất Cả Giao Dịch (<?php echo count($all_payments); ?>)</div>
            <?php if (empty($all_payments)): ?>
                <div style="text-align: center; padding: 2rem; color: #94a3b8;">Chưa có giao dịch nào trong kỳ.</div>
            <?php else: ?>
                <div style="max-height: 400px; overflow-y: auto;">
                    <table class="table" style="width: 100%;">
                        <thead>
                            <tr style="border-bottom: 2px solid #e2e8f0; text-align: left; position: sticky; top: 0; background: white;">
                                <th style="padding: 0.6rem;">Thời gian</th>
                                <th style="padding: 0.6rem;">Bệnh nhân</th>
                                <th style="padding: 0.6rem;">Phương thức</th>
                                <th style="padding: 0.6rem; text-align: right;">Số tiền</th>
                                <th style="padding: 0.6rem;">Người tạo</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($all_payments as $pay): ?>
                                <?php $ml = $method_labels[$pay['method']] ?? ['label' => $pay['method'], 'icon' => '❓', 'color' => '#94a3b8']; ?>
                                <tr style="border-bottom: 1px solid #f1f5f9;">
                                    <td style="padding: 0.6rem;">
                                        <div style="font-weight: 700; font-size: 0.9rem;"><?php echo date('H:i', strtotime($pay['created_at'])); ?></div>
                                        <div style="font-size: 0.75rem; color: #64748b;"><?php echo date('d/m/Y', strtotime($pay['created_at'])); ?></div>
                                    </td>
                                    <td style="padding: 0.6rem; font-weight: 600;"><?php echo e($pay['patient_name']); ?></td>
                                    <td style="padding: 0.6rem;">
                                        <span style="font-size: 0.8rem; padding: 0.2rem 0.6rem; border-radius: 6px; font-weight: 700; background: <?php echo $ml['color']; ?>20; color: <?php echo $ml['color']; ?>;">
                                            <?php echo $ml['icon']; ?> <?php echo $ml['label']; ?>
                                        </span>
                                    </td>
                                    <td style="padding: 0.6rem; text-align: right; font-weight: 800; color: <?php echo $pay['method'] === 'debt' ? '#ef4444' : '#1e293b'; ?>;">
                                        <?php echo format_money($pay['amount']); ?>
                                    </td>
                                    <td style="padding: 0.6rem; font-size: 0.8rem; color: #64748b;"><?php echo e($pay['created_by_name']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once '../../templates/footer.php'; ?>
